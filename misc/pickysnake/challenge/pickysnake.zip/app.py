#!/usr/bin/env python

import base64
import pickle
import pickletools

ALLOWED_OPCODES = [
    "GLOBAL",
    "INT",
    "STRING",
    "TUPLE1",
    "TUPLE2",
    "TUPLE3",
    "NEWTRUE",
    "NEWFALSE",
    "LONG1",
    "LONG4",
    "EMPTY_LIST",
    "EMPTY_TUPLE",
    "EMPTY_DICT",
    "APPEND",
    "SETITEM",
    "EXT1",
    "EXT2",
    "EXT4",
    "SHORT_BINSTRING",
    "REDUCE",
    "NONE",
    "DUP",
    "FLOAT",
    "POP",
    "POP_MARK",
    "STOP",
]

ALLOWED_GLOBAL_BEGIN = "copyreg _"


def unpickle(data):
    it = pickletools.genops(data)
    for op, arg, pos in it:
        if op.name not in ALLOWED_OPCODES:
            return f"opcode {op.name} is forbidden"
        if op.name == "GLOBAL":
            if not arg.startswith(ALLOWED_GLOBAL_BEGIN):
                return (
                    f"opcode {op.name} argument must begin with {ALLOWED_GLOBAL_BEGIN}"
                )
    return pickle.loads(data)


def main():
    b64data = input("Base 64 encoded data to unpickle > ")

    try:
        data = base64.b64decode(b64data)
    except Exception as e:
        print("Pickle data is not base64 encoded")
        return

    e = unpickle(data)
    if e is not None:
        print(f"Error unpickling data: {e}")
        return

    print(f"Data unpickled successfully! {e}")


if __name__ == "__main__":
    main()
