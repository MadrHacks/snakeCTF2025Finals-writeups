from parsy import Callable, decimal_digit, fail, forward_declaration, regex, string, generate
import interpreter
from options import options

comment = regex(r"#.*(?:\n|$)")
space = regex(r"[ \t\r\n]+")
whitespace = (space | comment).many().desc("whitespace or comments")

newline = regex(r"^\n")
lexeme = lambda p: p << whitespace
lbrace = lexeme(string("{"))
rbrace = lexeme(string("}"))
lbrack = lexeme(string("["))
rbrack = lexeme(string("]"))
colon = lexeme(string(":"))
comma = lexeme(string(","))
number = lexeme(regex(r"-?(0|[1-9][0-9]*)([.][0-9]+)?([eE][+-]?[0-9]+)?")).map(lambda x : interpreter.Number(float(x)))
string_part = regex(r'[^"\\]+')
string_esc = string("\\") >> (
    string("\\")
    | string("/")
    | string('"')
    | string("b").result("\b")
    | string("f").result("\f")
    | string("n").result("\n")
    | string("r").result("\r")
    | string("t").result("\t")
    | regex(r"u[0-9a-fA-F]{4}").map(lambda s: chr(int(s[1:], 16)))
)
quoted = lexeme(string('"') >> (string_part | string_esc).many().concat() << string('"')).map(interpreter.String)


expr = forward_declaration()
true = lexeme(string("true"))
false = lexeme(string("false"))
boolean = (true | false).map(lambda x: interpreter.Boolean(True) if x == 'true' else interpreter.Boolean(False))

name = lexeme(regex(r"[a-zA-Z_-]+"))
if options['only s']:
    varname = lexeme(regex(r"[s]+[sS]*"))
else:
    varname = lexeme(regex(r"[a-z]+[a-zA-Z_\-!?<>']*"))

var = varname.map(interpreter.Variable)
symbolname = lexeme(regex(r"[A-Z_.]+[a-zA-Z_-]*"))
symbol = symbolname.map(interpreter.Symbol)


@generate
def args():
    n_args = yield (varname << lexeme(string(","))).many()
    last_arg = yield varname.at_most(1)

    return n_args + last_arg

@generate
def lambda_():
    yield lexeme(string("\\"))
    args_ = yield lexeme(args)
    yield lexeme(string("->"))
    body = yield expr
    return interpreter.Function(args_, body)


def infix_binary_op(op_str: str, combine: Callable | None = None):
    @generate
    def op_parser():
        x = yield lexeme(expr)
        yield lexeme(string(op_str))
        y = yield lexeme(expr)
        if combine:
            return combine(x,y)
        else:
            return (x,y)

    return op_parser

@generate
def expr_in_parentheses():
    yield lexeme(string("("))
    expr_ = yield expr
    yield lexeme(string(")"))
    return expr_

if options['weird calls']:
    @generate
    def function_call():
        yield lexeme(string("("))
        args_ = yield (lexeme(expr) << lexeme(string(","))).many() + lexeme(expr).at_most(1)
        yield lexeme(string(")"))

        if len(args_) == 1:
            fname = args_[0]
            fargs = []
        elif len(args_) > 1:
            fname = args_[-2]
            fargs = args_[:-2] + [args_[-1]]
        else:
            return fail("Provide at least the function name")

        return interpreter.FunctionCall(fname, fargs)
else:
    @generate
    def function_call():
        fname = yield var | expr_in_parentheses
        yield lexeme(string("("))
        args_ = yield (lexeme(expr) << lexeme(string(","))).many() + lexeme(expr).at_most(1)
        yield lexeme(string(")"))
        return interpreter.FunctionCall(fname, args_)

@generate
def variable_assign():
    var_ = yield var
    yield lexeme(string("="))
    expr_ = yield expr
    return interpreter.Assignment(var_, expr_)

@generate
def let():
    yield lexeme(string("let"))
    varname_ = yield varname
    yield lexeme(string("="))
    val = yield expr
    yield lexeme(string("in"))
    body = yield expr
    return interpreter.Let(varname_, val, body)

@generate
def if_():
    yield lexeme(string("if"))
    cond = yield expr

    yield lexeme(string("then"))
    then = yield expr

    else_ = None
    yield lexeme(string("else")).optional()
    else_ = yield expr.optional()

    return interpreter.IfThenElse(cond, then, else_)

@generate
def sequence():
    yield lexeme(string("{"))
    exprs = yield (lexeme(expr) << lexeme(string(";")).optional()).many()
    yield lexeme(string("}"))
    return interpreter.ExpressionSequence(exprs)

@generate
def share_environment():
    open_paren = None
    open_paren = yield lexeme(string("[")).optional()
    func = yield var
    yield string(":")
    if open_paren:
        yield lexeme(string("]"))
    take_env_from = yield var
    return interpreter.ShareEnvironment(func, take_env_from)

@generate
def force():
    yield lexeme(string("force"))
    expr_ = yield expr
    return interpreter.ForceExpression(expr_)

@generate
def uplevel():
    yield lexeme(string("uplevel"))
    num = yield lexeme(decimal_digit.at_least(1)).map(lambda digits : int("".join(digits))).optional()

    force_opt = yield lexeme(string("force")).optional()
    call = yield function_call
    call.uplevel = num if num else 0
    if force_opt:
        return interpreter.ForceExpression(call)
    else:
        return call

atom = number | boolean | symbol
expr =  sequence \
     | share_environment \
     | function_call \
     | variable_assign \
     | lambda_ \
     | uplevel \
     | force \
     | var \
     | atom \

program = whitespace >> expr << whitespace
