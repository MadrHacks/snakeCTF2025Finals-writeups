from dataclasses import dataclass, field
from typing import List, Any, Mapping, Optional, Self
from options import options

Name = str

type Bindings = Mapping

@dataclass
class LexicalEnv:
    bindings : Optional[Bindings] = field(default_factory=dict)
    parent : Optional[Self] = None

    def get(self, name: Name) -> Optional[Any]:
        if name in self.bindings:
            return self.bindings[name]
        if self.parent is None:
            return None
        return self.parent.get(name)

    def extend(self, new_bindings: Mapping[Name, Any]) -> "LexicalEnv":
        return LexicalEnv(bindings=new_bindings, parent=self)

    def __repr__(self) -> str:
        return f"LexicalEnv({self.bindings}, parent={bool(self.parent)})"


@dataclass
class DynamicFrame:
    bindings: Optional[Bindings] = field(default_factory=dict)
    parent: Optional[Self] = None

    def get_local(self, name: Name) -> Optional[Any]:
        if name in self.bindings:
            return self.bindings[name]
        if self.parent is None:
            return None
        return self.parent.get_local(name)

    def find_frame_with(self, name: Name) -> Optional[Self]:
        if name in self.bindings:
            return self
        if self.parent is None:
            return None
        return self.parent.find_frame_with(name)

    def add_local(self, name: Name, value: Any) -> None:
        self.bindings[name] = value

    def set_existing(self, name: Name, value: Any) -> bool:
        frame = self.find_frame_with(name)
        if frame is None:
            return False
        frame.bindings[name] = value
        return True

    def ancestor(self, k: int) -> Optional["DynamicFrame"]:
        frame = self
        for _ in range(k):
            if frame is None:
                return None
            frame = frame.parent
        return frame

    def __repr__(self) -> str:
        return f"DynamicFrame({self.bindings}, parent={bool(self.parent)})"


@dataclass
class Environment:
    lexical : Optional[LexicalEnv] = field(default_factory=LexicalEnv)
    dynamic : Optional[DynamicFrame] = field(default_factory=DynamicFrame)

    def get_binding(self, name: Name) -> Optional[Any]:
        val = self.lexical.get(name)
        if val is not None:
            return val
        return self.dynamic.get_local(name)

    def set_binding(self, name: Name, value: Any) -> None:
        if self.dynamic.set_existing(name, value):
            return
        self.dynamic.add_local(name, value)

        if options['rotate']:
            self.dynamic.bindings = rotate(self.dynamic.bindings)

    def add_binding(self, name: Name, value: Any) -> None:
        self.dynamic.add_local(name, value)

    def get_dynamic_ancestor(self, k: int) -> DynamicFrame:
        ancestor = self.dynamic.ancestor(k)
        if ancestor is None:
            raise Exception(f"Can't go up {k} dynamic frames")
        return ancestor

    def with_lexical(self, new_lex: LexicalEnv) -> "Environment":
        return Environment(lexical=new_lex, dynamic=self.dynamic)

    def with_dynamic(self, new_dyn: DynamicFrame) -> "Environment":
        return Environment(lexical=self.lexical, dynamic=new_dyn)

    def __repr__(self):
        return f"Environment(lex={self.lexical}, dyn={self.dynamic})"

def rotate(d: dict):
    keys = list(d.keys())
    if len(keys) > 0:
        last = d[keys[0]]
        for i in range(1, len(keys)):
            curr = d[keys[i]]
            d[keys[i]] = last
            last = curr
        d[keys[0]] = last
    return d

@dataclass
class Expression:
    def evaluate(self, env: Environment) -> Any:
        pass

@dataclass
class Function(Expression):
    args: List[str]
    body: Expression
    env: LexicalEnv = field(default_factory=LexicalEnv)

    def evaluate(self, env: Environment) -> "Function":
        return Function(self.args, self.body, env.lexical)

    def __repr__(self) -> str:
        return f"\\ {', '.join(self.args)} -> {repr(self.body)}"


@dataclass
class FunctionCall(Expression):
    function: Expression
    args: List[Expression]
    uplevel: int = 0

    def evaluate(self, env: Environment):
        function = self.function.evaluate(env)
        if not isinstance(function, Function):
            raise TypeError(f"{function} is not a Function")

        if len(self.args) < len(function.args):
            caller_dyn_parent = env.dynamic
            call_frame = DynamicFrame(parent=caller_dyn_parent)
            for (param, arg_expr) in zip(function.args, self.args):
                call_frame.add_local(param, Thunk(arg_expr, env))
            partial_bindings = {}
            for (param, _) in zip(function.args, self.args):
                partial_bindings[param] = call_frame.get_local(param)
            new_lex = function.env.extend(partial_bindings)
            leftover_args = function.args[len(self.args):]
            return Function(leftover_args, function.body, new_lex)

        if len(self.args) > len(function.args):
            raise Exception(f"function {self.function} expects {len(function.args)} arguments but {len(self.args)} were given")

        if self.uplevel > 0:
            activation = env.get_dynamic_ancestor(self.uplevel)
        else:
            target_dyn_parent = env.dynamic

            activation = DynamicFrame(parent=target_dyn_parent)

        new_bindings = dict()
        for (param, arg_expr) in zip(function.args, self.args):
            new_bindings[param] = Thunk(arg_expr, env)

        call_env = Environment(lexical=function.env.extend(new_bindings), dynamic=activation)

        return function.body.evaluate(call_env)

    def __repr__(self) -> str:
        return f"{repr(self.function)}({', '.join(repr(a) for a in self.args)})"

@dataclass
class Atom(Expression):
    value : Any

    def evaluate(self, env: Environment) -> Any:
        return self

    def __repr__(self) -> str:
        return repr(self.value).lower()

@dataclass
class Number(Atom):
    value: int

    def evaluate(self, env: Environment):
        return Number(int(self.value))

    def __repr__(self) -> str:
        return super().__repr__()


@dataclass
class Null(Atom):
    value: None = None

    def evaluate(self, env: Environment):
        return self

    def __repr__(self) -> str:
        return "null"

    def __bool__(self):
        return False

@dataclass
class String(Atom):
    value: str

    def __repr__(self) -> str:
        return f'"{self.value}"'

@dataclass
class Symbol(Atom):
    value: str

    def evaluate(self, env: Environment) -> Any:
        return self

    def __repr__(self) -> str:
        return f'{self.value}'

@dataclass
class Boolean(Atom):
    value: bool

    def __repr__(self) -> str:
        return super().__repr__()

@dataclass
class Variable(Expression):
    name: str

    def evaluate(self, env: Environment):
        val = env.get_binding(self.name)
        if val is None:
            raise Exception(f"name {self.name} not known")
        if isinstance(val, Thunk):
            return val.force()
        return val

    def __repr__(self) -> str:
        return self.name

@dataclass
class PrintOutput(Expression):
    what: Expression

    def evaluate(self, env: Environment) -> Any:
        val = self.what.evaluate(env)
        print(str(val), end="")
        return Number(len(str(val)))

    def __repr__(self) -> str:
        return f"out({repr(self.what)})"

@dataclass
class ReadInput(Expression):
    prompt: Expression

    def evaluate(self, env: Environment) -> Any:
        return String(input(self.prompt.evaluate(env)))

    def __repr__(self) -> str:
        return f"inp({repr(self.prompt)})"

@dataclass
class NumberAddition(Expression):
    x: Expression
    y: Expression

    def evaluate(self, env: Environment):
        left = self.x.evaluate(env)
        right = self.y.evaluate(env)

        if not isinstance(left, Number):
            raise TypeError(f"{left} is not of type Number")
        if not isinstance(right, Number):
            raise TypeError(f"{right} is not of type Number")

        return Number(left.value + right.value)

    def __repr__(self) -> str:
        return f"add({repr(self.x)}, {repr(self.y)})"

@dataclass
class StringConcatenation(Expression):
    x: Expression
    y: Expression

    def evaluate(self, env: Environment) -> Any:
        left = self.x.evaluate(env)
        right = self.y.evaluate(env)

        if not isinstance(left, String):
            raise TypeError(f"{left} is not of type String")
        if not isinstance(right, String):
            raise TypeError(f"{right} is not of type String")

        return String(left.value + right.value)

@dataclass
class NumberSubtraction(Expression):
    x: Expression
    y: Expression

    def evaluate(self, env: Environment):
        left = self.x.evaluate(env)
        right = self.y.evaluate(env)

        if not isinstance(left, Number):
            raise TypeError(f"{left} is not of type Number")
        if not isinstance(right, Number):
            raise TypeError(f"{right} is not of type Number")

        return Number(left.value - right.value)

    def __repr__(self) -> str:
        return f"sub({repr(self.x)}, {repr(self.y)})"

@dataclass
class IfThenElse(Expression):
    condition: Expression
    then: Expression
    else_: Expression | None = None

    def evaluate(self, env: Environment):
        cond = self.condition.evaluate(env)
        if cond != Null() and cond != Boolean(False):
            return self.then.evaluate(env)
        elif self.else_:
            return self.else_.evaluate(env)
        else:
            return Null()

    def __repr__(self) -> str:
        if self.else_:
            return f"if {repr(self.condition)} then {repr(self.then)}"
        else:
            return f"if {repr(self.condition)} then {repr(self.then)} else {repr(self.else_)}"

@dataclass
class Equals(Expression):
    x: Expression
    y: Expression

    def evaluate(self, env: Environment):
        return Boolean(self.x.evaluate(env).__dict__  == self.y.evaluate(env).__dict__)

    def __repr__(self) -> str:
        return f"eq({repr(self.x)}, {repr(self.y)})"

@dataclass
class Not(Expression):
    x: Expression

    def evaluate(self, env: Environment):
        val = self.x.evaluate(env)
        if val == Boolean(False) or val == Null():
            return Boolean(True)
        else:
            return Boolean(False)

    def __repr__(self) -> str:
        return f"not({repr(self.x)})"

@dataclass
class And(Expression):
    left: Expression
    right: Expression

    def evaluate(self, env: Environment,):
        left = self.left.evaluate(env)
        if left != Boolean(False) and left != Null():
            right = self.right.evaluate(env)
            return right
        else:
            return left

    def __repr__(self) -> str:
        return f"and({repr(self.left)}, {repr(self.right)})"

@dataclass
class Or(Expression):
    left: Expression
    right: Expression

    def evaluate(self, env: Environment):
        left = self.left.evaluate(env)
        if left != Boolean(False) and left != Null():
            return left
        else:
            right = self.right.evaluate(env)
            return right

    def __repr__(self) -> str:
        return f"or({repr(self.left)}, {repr(self.right)})"

@dataclass
class Let(Expression):
    name: Name
    val: Expression
    body: Expression | None = None

    def evaluate(self, env: Environment) -> Any:
        aug_env = Environment(parent_envs=[env])
        thunk = Thunk(self.val, aug_env)
        aug_env.add_binding(self.name, thunk)
        if self.body:
            return self.body.evaluate(aug_env)
        return thunk.force()

    def __repr__(self) -> str:
        return f"let {self.name} = {repr(self.val)} in {repr(self.body)}"


@dataclass
class ExpressionSequence(Expression):
    exprs: List[Expression]

    def evaluate(self, env: Environment) -> Any:
        for x in self.exprs[:-1]:
            x.evaluate(env)
        return self.exprs[-1].evaluate(env)

    def __repr__(self) -> str:
        return "{" + "; ".join(repr(e) for e in self.exprs) + "}"

@dataclass
class Assignment(Expression):
    variable: Variable
    value: Expression

    def evaluate(self, env: Environment) -> Any:
        if isinstance(self.value, ForceExpression):
            value = self.value.evaluate(env)
        else:
            value = Thunk(self.value, env)
        env.set_binding(self.variable.name, value)

        return value

    def __repr__(self) -> str:
        return f"{repr(self.variable)} = {repr(self.value)}"


@dataclass
class ToString(Expression):
    value: Any

    def evaluate(self, env: Environment) -> Any:
        val = self.value.evaluate(env)
        if isinstance(val, String):
            return val
        return String(str(val))

@dataclass
class NoOp(Expression):
    def evaluate(self, env: Environment) -> Any:
        pass

@dataclass
class Thunk:
    expr: Expression
    env: Environment
    value: Any = None
    evaluated: bool = False

    def force(self):
        if not self.evaluated:
            self.value = self.expr.evaluate(self.env)
            self.evaluated = True
        return self.value

    def __repr__(self) -> str:
        if self.evaluated:
            return repr(self.value)
        return f"thunked expression <{repr(self.expr)}>"


@dataclass
class ForceExpression(Expression):
    expr: Expression

    def evaluate(self, env: Environment) -> Any:
        if isinstance(self.expr, Thunk):
            return self.expr.force()
        return self.expr.evaluate(env)


@dataclass
class ShareEnvironment(Expression):
    func: Variable
    take_env_from: Variable

    def evaluate(self, env: Environment) -> Any:
        func = self.func.evaluate(env)
        take_env_from = self.take_env_from.evaluate(env)

        if not isinstance(func, Function):
            raise TypeError(f"{func} must evaluate to a Function")
        if not isinstance(take_env_from, Function):
            raise TypeError(f"{take_env_from} should evaluate to a Function")

        func.env = take_env_from.env
        return func

@dataclass
class NumberToChar(Expression):
    x : Expression

    def evaluate(self, env: Environment) -> Any:
        x = self.x.evaluate(env)
        if not isinstance(x, Number):
            raise TypeError(f"{x} should be of type Number")
        return chr(x.value)
