#!/usr/bin/env python3

import parser as p
from typing import Any
import argparse
from pprint import pprint
import sys
from interpreter import *
import os
from options import options


def wrap_list(x : list):
    l = Null()
    for y in x[::-1]:
        if options['only s']:
            l = FunctionCall(Variable("sSs"), [wrap_builtin_type(y), l])
    return l

def wrap_builtin_type(x) -> Expression:
    if isinstance(x, bool):
        return Boolean(x)
    if isinstance(x, int):
        return Number(x)
    if isinstance(x, list):
        return wrap_list(x)
    if isinstance(x, str):
        return wrap_list([ord(c) for c in x])
    if isinstance(x, tuple):
        if len(x) == 2:
            if options['only s']:
                l = FunctionCall(Variable("sSs"), [wrap_builtin_type(x[0]), wrap_builtin_type(x[1])])
        else:
            return wrap_list(list(x))
    if isinstance(x, dict):
        keys_values = wrap_list(list(x.items()))
        if options['only s']:
            return FunctionCall(Variable("SSSSSSSS"), [FunctionCall(Variable("SSSSsSSS"), []), keys_values])
        else:
            return FunctionCall(Variable("init-map"), [FunctionCall(Variable("make-map"), []), keys_values])

    raise TypeError(f"{x} can't be mapped to a known language construct")

def wrap_function(f, *args):
    class Wrapper(Expression):
        def evaluate(self, env: Environment) -> Any:
            eval_args = [arg.evaluate(env).value for arg in args]
            return wrap_builtin_type(f(*eval_args)).evaluate(env)

        def __repr__(self):
            return f"<wrapped function {f.__name__}>"

    return Wrapper()

if options['only s']:
    global_env = Environment(dynamic=DynamicFrame({
        "sssss": Function(["s", "ss"], And(Variable("s"), Variable("ss"))),
        "ssssS": Function(["s"], Not(Variable("s"))),
        "sssSs": Function(["s", "ss"], NumberAddition(Variable("s"), Variable("ss"))),
        "sssSS": Function(["s", "ss"], NumberSubtraction(Variable("s"), Variable("ss"))),
        "ssSss" : Function(["s", "ss"], Equals(Variable("s"), Variable("ss"))),
        "ssSsS" : Function(["s"], PrintOutput(Variable("s"))),
        "ssSSs": Function(["s"], NumberToChar(Variable("s"))),
        "ssSSS": Boolean(True),
        "sSsss": Boolean(False),
        "sSssS": Null(),
        "sSsSs" : Function(["s"], ReadInput(Variable("s"))),
        "sSsSS": Function(["s"], wrap_function(os.getenv, Variable("s"))),
    }))

read_input_bytes = 0

def evaluate(code: str):
    global read_input_bytes
    read_input_bytes += len(code)
    if read_input_bytes > options['input limit']:
        sys.exit()

    program = p.program.parse(code)
    return program.evaluate(global_env)

def repl():
    while True:
        try:
            code = input("π ")
            if code == "":
                continue
            result = evaluate(code)
            if result:
                pprint(result)
        except KeyboardInterrupt:
            print("K bye")
            sys.exit()
        except Exception as e:
            print(f"[ERROR] {e}")
            # raise e

def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("filename", nargs="?", type=str)
    parser.add_argument("-i", "--interactive", action="store_true")
    return parser

def main():

    argparser = make_parser()
    args = argparser.parse_args()

    if args.filename:
        with open(args.filename, "r") as f:
            code = f.read()
        evaluate("{" + code + "}")
        if args.interactive:
            repl()
    else:
        repl()

if __name__ == "__main__":
    main()
