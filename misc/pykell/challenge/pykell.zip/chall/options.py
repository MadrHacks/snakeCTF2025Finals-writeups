options = {
    "only s": True,
    "rotate": True,
    "weird calls": True,
    "input limit": 300,
}
