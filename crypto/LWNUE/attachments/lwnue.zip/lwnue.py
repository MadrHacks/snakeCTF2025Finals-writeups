from random import randint, choice
from sage.all import *
from Crypto.Util.number import bytes_to_long


def chunk_string(s, n):
    return [int(s[i:i + n], 2) for i in range(0, len(s), n)]


def transform_flag(flag, max_bin):
    value_flag = bytes_to_long(flag)
    bin_flag = bin(value_flag)[2:]
    return chunk_string(bin_flag, max_bin)


class LWNUE:
    def __init__(self):
        self.prime = 65537
        self.nv_per_block = 5
        self.n_lines_per_block = 50
        self.n_blocks = 10
        self.nvalues_error = 8
        self.value_errors = [[randint(0, self.prime - 1) for _ in range(self.nvalues_error)] for _ in
                             range(self.n_blocks)]

    def gen_A(self):
        self.A = []

        for i in range(self.n_blocks):
            for j in range(self.n_lines_per_block):
                row = [randint(0, self.prime - 1) for _ in range((i + 1) * self.nv_per_block)] + (
                            [0] * ((self.n_blocks - i - 1) * self.nv_per_block))
                self.A.append(row)

        self.A = Matrix(GF(self.prime), self.A)

    def gen_secret(self, flag):
        secret_flag = transform_flag(bytes.fromhex(flag), len(bin(self.prime)[2:]) - 1)
        # secret_flag = secret_flag[:self.nv_per_block*self.n_blocks]
        assert len(secret_flag) == self.nv_per_block * self.n_blocks
        self.secret = vector(GF(self.prime), secret_flag)

    def get_output(self, fresh_A=False):
        if fresh_A:
            self.gen_A()

        error = []
        for i in range(self.n_blocks):
            for _ in range(self.n_lines_per_block):
                error.append(choice(self.value_errors[i]))
        error = vector(GF(self.prime), error)

        output = self.A * self.secret + error
        return output, self.A
