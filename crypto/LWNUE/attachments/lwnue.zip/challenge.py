#!/usr/bin/env sage

import os
import signal
from lwnue import LWNUE
from sage.all import *


TIMEOUT = 1000

assert ("FLAG" in os.environ)
FLAG = os.environ["FLAG"]
FLAG = FLAG[FLAG.index("snakeCTF{")+9:-1] 


def main():
    max_outputs = 30 
    LWE = LWNUE()
    LWE.gen_A()
    LWE.gen_secret(FLAG)
    
    while True:
        print(""" 
        MENU:
            1) Get public parameters
            2) Get output
            3) Exit
            """)

        choice = input("> ")

        if choice == "1":
            print(f"value_errors = {LWE.value_errors}")
        elif choice == "2":
            if max_outputs == 0:
                print("Attempts are finished.")
                break
            max_outputs -= 1
            output, new_A = LWE.get_output(fresh_A=True)
            print(f"output = {output}")
            print()
            print(f"A = {list(new_A)}")
            print()

        elif choice == "3":
            break


if __name__ == "__main__":
    signal.alarm(TIMEOUT)
    main()
