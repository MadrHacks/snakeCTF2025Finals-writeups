from random import randint, shuffle
from Crypto.Util.number import bytes_to_long

MAX_TOTAL_DEGREE = 5
NV = 5
MODULE = 1032098924799280315192066093914417833177833302509923976176862882554638250887213068224206200449666351562189626707393555904112281625034026678125456551667513031790708773416934064969671012907368478140699734965174298114190184588488033058780076659645135913000113007258713193105998654166184899482369062344513470660765604832747482847821535712069498813383462458892560047800940095143727512682768774742514981525666639719294825042155037328403186641900374428417685854578605733880089383148616427623425021212964908921358689683850949592234278922757515888451816099635192292688571352927234850499433850633417328946258142008283


def gen_random_polynomial(FLAG):
    monomials = []
    coefficients = []
    n_terms = randint(300, 1000)
    for _ in range(n_terms):
        current_degree = MAX_TOTAL_DEGREE
        m = []
        for _ in range(NV):
            deg = randint(0, current_degree)
            current_degree = current_degree - deg
            m.append(deg)
        shuffle(m)
        m = tuple(m)
        c = randint(0, MODULE - 1)
        monomials.append(m)
        coefficients.append(c)

    # known coefficient constraint
    monomials.append(tuple([0 for _ in range(NV)]))
    coefficients.append(bytes_to_long(FLAG.encode()))

    return monomials, coefficients


def evaluate_polynomial(monomials, coefficients, inputs):
    assert len(inputs) == NV
    res = 0
    for m, c in zip(monomials, coefficients):
        value = 1
        for i in range(NV):
            value = (value * inputs[i] ** m[i]) % MODULE
        value = (value * c) % MODULE
        res = (res + value) % MODULE
    return res


def main(FLAG):
    monomials, coefficients = gen_random_polynomial(FLAG)
    points = []

    while len(points) != 600:
        input = [randint(0, MODULE - 1) for _ in range(NV)]
        res = evaluate_polynomial(monomials, coefficients, input)
        input.append(res)
        if input not in points:
            points.append(input)

    return points


if __name__ == '__main__':
    points = main("snakeCTF{this_is_a_fake_flag}")
    with open("intercepted_points.txt", "w") as file:
        file.write(str(points))
        file.close()
