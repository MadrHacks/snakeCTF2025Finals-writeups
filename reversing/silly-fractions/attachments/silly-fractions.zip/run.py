from sympy import primerange
import math
import sys

def parse_fractions(input_name):
	fracs = []
	with open(input_name, 'r') as input_f:
		for line in input_f:
			if not line.startswith('%') and '/' in line:
				s_num, _, s_den = line.partition('/')
				fracs.append((int(s_num), int(s_den)))
	acct = [set(j
		for j in range(len(fracs)) if math.gcd(fracs[i][0], fracs[j][1]) > 1)
		for i in range(len(fracs))]
	return fracs, acct

def check_flag(flag):
	fracs, acct = parse_fractions('checker.frac')
	print('verifying...')
	active = set(range(len(fracs)))
	state = math.prod([p**e for p, e in zip(primerange(224), flag)]) * 227
	while active:
		idx = min(active)
		num, den = fracs[idx]
		if state % den:
			active.remove(idx)
			continue
		state = (state // den) * num
		active.update(acct[idx])
	return state == 229

if __name__ == '__main__':
	sys.set_int_max_str_digits(1_000_000)
	flag = input('flag? ').encode('ascii')
	assert len(flag) == 48
	print('correct, nice work!' if check_flag(flag) else 'wrong, sorry')
