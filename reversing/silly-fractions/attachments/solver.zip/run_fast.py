#!/usr/bin/env python3
# (c) 2025 rw-r-r-0644, MIT license

from collections import defaultdict
from sympy import primerange, factorint
import heapq
import math
import time
import sys

FLAG_LEN = 48
PRIME_FACTORS = [*primerange(65536)]
PRIME_FACTORS_IDX = {p: i for i, p in enumerate(PRIME_FACTORS)}

def factor_idx(n):
	return [(PRIME_FACTORS_IDX[p], e) for p, e in factorint(n).items()]

def load_raw_fractions(filename):
	with open(filename, 'r') as input_f:
		input_l = input_f.readlines()
	fractions = []
	for line in input_l:
		if not line.startswith('%') and '/' in line:
			s_num, _, s_den = line.partition('/')
			fractions.append((int(s_num), int(s_den)))
	return fractions

class SillyFractions:
	def run(self, start):
		maybe_int_set = set(range(self.frac_count))
		maybe_int_heap = list(maybe_int_set)
		heapq.heapify(maybe_int_heap)

		state_fact = [0] * (self.max_prime_idx + 1)
		for pi, e in factor_idx(start):
			state_fact[pi] = e

		while maybe_int_set:
			# if state is still an integer if multiplied by min idx fraction, multiply it
			min_idx = maybe_int_heap[0]
			if any(state_fact[pi] < e for pi, e in self.den_factors[min_idx]):
				heapq.heappop(maybe_int_heap)
				maybe_int_set.remove(min_idx)
				continue

			for pi, e in self.den_factors[min_idx]:
				state_fact[pi] -= e
			for pi, e in self.num_factors[min_idx]:
				state_fact[pi] += e
				for idx in self.frac_lookup[pi]:
					if idx in maybe_int_set:
						continue
					heapq.heappush(maybe_int_heap, idx)
					maybe_int_set.add(idx)

		return math.prod(PRIME_FACTORS[pi]**e for pi, e in enumerate(state_fact))

	def __init__(self, filename):
		raw_frac = load_raw_fractions(filename)
		self.frac_count = len(raw_frac)
		self.num_factors = [factor_idx(num) for num, _ in raw_frac]
		self.den_factors = [factor_idx(den) for _, den in raw_frac]
		self.max_prime_idx = max(pi
			for factor in self.num_factors + self.den_factors
			for pi, _ in factor)
		self.frac_lookup = [[] for _ in range(self.max_prime_idx + 1)]
		for idx in range(self.frac_count):
			for pi, _ in self.den_factors[idx]:
				self.frac_lookup[pi].append(idx)

def check_flag(program, flag):
	inp = math.prod(p**e for (p, e) in zip(PRIME_FACTORS, flag)) * PRIME_FACTORS[FLAG_LEN]
	checker = SillyFractions(program)
	return checker.run(inp) == PRIME_FACTORS[FLAG_LEN + 1]

if __name__ == '__main__':
	sys.set_int_max_str_digits(1_000_000)
	flag = input('flag? ').encode('ascii')
	print('verifying...')
	print('correct, nice work!' if check_flag('checker.frac', flag) else 'wrong, sorry')