#!/usr/bin/env python3
# (c) 2025 rw-r-r-0644, MIT license

from collections import defaultdict
from sympy import primerange, factorint
import heapq
import math
import time
import sys
import os
import subprocess
from run_fast import check_flag
from cipher_48 import *

sys.set_int_max_str_digits(1_000_000)

FLAG_LEN = 48
PRIME_FACTORS = [*primerange(65536)]
PRIME_FACTORS_IDX = {p: i for i, p in enumerate(PRIME_FACTORS)}

def factor_idx(n):
	return [(PRIME_FACTORS_IDX[p], e) for p, e in factorint(n).items()]

def load_raw_fractions(filename):
	with open(filename, 'r') as input_f:
		input_l = input_f.readlines()
	fractions = []
	for line in input_l:
		if not line.startswith('%') and '/' in line:
			s_num, _, s_den = line.partition('/')
			fractions.append((int(s_num), int(s_den)))
	return fractions

assert len(sys.argv) > 1, "usage: solve.py <checker.frac>"
raw_frac = load_raw_fractions(sys.argv[1])
frac_count = len(raw_frac)
num_factors = [factor_idx(num) for num, _ in raw_frac]
den_factors = [factor_idx(den) for _, den in raw_frac]
max_prime_idx = max(pi
	for factor in num_factors + den_factors
	for pi, _ in factor)
den_lookup = [[] for _ in range(max_prime_idx + 1)]
num_lookup = [[] for _ in range(max_prime_idx + 1)]
for idx in range(frac_count):
	for pi, _ in den_factors[idx]:
		den_lookup[pi].append(idx)
	for pi, _ in num_factors[idx]:
		num_lookup[pi].append(idx)

# find a set of rules such that:
# - any of pre_any are in the denominator (preconditions)
# - all of pre_all are in the denominator (preconditions)
# - any of post_any are in the numerator (postconditions)
# - all of post_all are in the numerator (postconditions)
def find_rules(pre_any=[], pre_all=[], post_any=[], post_all=[]):
	# add candidates that satisfy _any conditions (ignore degree for now)
	candidates_pre_any = set() if pre_any else set(range(frac_count))
	for pi, _ in pre_any:
		candidates_pre_any.update(den_lookup[pi])
	candidates_post_any = set() if post_any else set(range(frac_count))
	for pi, _ in post_any:
		candidates_post_any.update(num_lookup[pi])
	candidates = candidates_pre_any & candidates_post_any

	# remove candidates that cannot satisfy _all conditions (ignore degree for now)
	for pi, _ in pre_all:
		candidates &= set(den_lookup[pi])
	for pi, _ in post_all:
		candidates &= set(num_lookup[pi])

	# now check degrees
	result = set()
	for idx in candidates:
		cden_factors = dict(den_factors[idx])
		cnum_factors = dict(num_factors[idx])
		good = all(cden_factors.get(pi, 0) >= e for pi, e in pre_all) \
			and all(cnum_factors.get(pi, 0) >= e for pi, e in post_all) \
			and (not pre_any) or any(cden_factors.get(pi, 0) >= e for pi, e in pre_any) \
			and (not post_any) or any(cnum_factors.get(pi, 0) >= e for pi, e in post_any)
		if good:
			result.add(idx)
	return result

def find_one_rule(pre_any=[], pre_all=[], post_any=[], post_all=[]):
	rules = find_rules(pre_any, pre_all, post_any, post_all)
	assert rules and len(rules) == 1
	return rules.pop()



# these are hardcoded and we know them from run.py
S_Start = 48
S_Success = 49


# NOTE: this part is just so that our solver will work on any generic checker.frac file,
# normally you can just hardcode all of these once you figure out which rule contains
# the encrypted flag and key!

# extract the encrypted flag and key starting from the success state
R_CheckResult2__Success = find_one_rule(post_all=[(S_Success, 1)])
S_CheckResult2 = den_factors[R_CheckResult2__Success][0][0]

R_CheckResult_PMatch__CheckResult2 = find_one_rule(post_all=[(S_CheckResult2, 1)])
T_CheckResult = [idx for idx, (pi, e) in enumerate(den_factors[R_CheckResult_PMatch__CheckResult2]) if e == 1][0]
S_CheckResult = den_factors[R_CheckResult_PMatch__CheckResult2][T_CheckResult][0]
S_PMatch, flag_enc_hw = den_factors[R_CheckResult_PMatch__CheckResult2][1 - T_CheckResult]

# collect all terms which increase S_PMatch to reconstruct enc flag bits
flag_check_terms = find_rules(post_all=[(S_PMatch, 1)])

flag_enc = [0] * FLAG_LEN
for idx in flag_check_terms:
	den_facs = den_factors[idx]

	# one of them is S_CheckResult, the other is the flag input with exponent set to the bit that must be set
	flag_term, flag_bit = [(pi, e) for pi, e in den_facs if pi != S_CheckResult][0]
	flag_enc[flag_term] |= flag_bit

# identify the key addition step to recover the key
# the key addition rules is designed to be fairly easiy to spot: we add all key bytes at once, so the numerator will be *very* large
numerators = [num for num, _ in raw_frac]
max_numerator = max(numerators)
add_key_rule_idx = numerators.index(max_numerator)
add_key_rule_post = dict(num_factors[add_key_rule_idx])




# we know have the key and encrypted flag; once we have reconstructed
# how the cipher works by analysing checker.frac, we can decrypt the flag
# and recover the key!
key = [add_key_rule_post.get(i, 0) for i in range(48)]
flag = decrypt(bytes(flag_enc), key)

# to be extra-sure everything went well, try to run the the solver with our flag as input
if not check_flag(sys.argv[1], flag):
	print("Decrypted flag failed verification!")
	sys.exit(1)

# yayy, we are good; let's print the flag!
print(flag.decode())

# hope you had fun with this chall! :3

