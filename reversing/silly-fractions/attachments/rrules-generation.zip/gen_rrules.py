#!/usr/bin/env python3
#
# gen_rrules.py
# FRACTRAN is basically a multiset rewriting system, so we can mostly use it as one
#
# (c) 2025 rw-r-r-0644, MIT license

import random
import sys
import os
from cipher_48 import *


RANDOMIZE = False
KEY = [*os.urandom(48)]

assert len(sys.argv) == 2, "usage: gen_rrules.py <flag>"
FLAG = sys.argv[1].encode()

assert len(FLAG) == 48, "flag must be 48 bytes"
ENC_FLAG = encrypt(FLAG, KEY)

assert decrypt(ENC_FLAG, KEY) == FLAG, "cipher sanity check failed!"


def shuffled(in_arr):
	out_arr = [*in_arr]
	if RANDOMIZE:
		random.shuffle(out_arr)
	return out_arr


# randomly interleave lists, maintaining each list's internal order
def mix_rules(rule_lists):
	pop_order = []
	for i in range(len(rule_lists)):
		pop_order += [i]*len(rule_lists[i])
	if RANDOMIZE:
		random.shuffle(pop_order)
	return [rule_lists[p].pop(0) for p in pop_order]



####################################
# mod-256 reduction rules
####################################
rules_mod256 = shuffled([
	((f'InputModReduct', f'Input{i}^256',), ()) for i in range(INPUT_LEN)
]) + [
	(('InputModReduct',), ()),
]


####################################
# add round key rule
####################################

# doing all key-bytes additions at once should yield
# a fraction with a gigantic numerator

# (we can split this if necessary, but it may help out
# as a starting point for the analysis)

rules_addroundkey = [
	(('DoAddRoundKey',), ('DoneAddRoundKey',f'InputModReduct^{INPUT_LEN}') + tuple(f'Input{i}^{KEY[i]}' for i in range(INPUT_LEN))),
]



####################################
# state permutation rules
####################################
rules_perm_mix = []

# rules for the same byte must follow MSB-first order, order wrt other byte rules can be randomized
for j in range(0, len(PERM), 8):
	rules_perm_mix.append([
		((f'DoPerm', f'Input{i >> 3}^{1 << (i & 7)}',), (f'DoPerm1', f'State{PERM[i] >> 3}^{1 << (PERM[i] & 7)}',))
		for i in range(j+7, j-1, -1)
	])
rules_perm = [(('DoPerm1',), ('DoPerm',))] + mix_rules(rules_perm_mix) + [(('DoPerm',),('DonePerm',))]




if SBOX_IS_4_BIT:
	####################################
	# 4-bit sbox substitution rules
	####################################

	# randomize subst order, but ensure high-byte substitution always happens
	# *before* low-byte substitution (otherwise results will be wrong!)

	subst_order = mix_rules([[j*2 + 1, j*2] for j in range(INPUT_LEN)])
	def subst_label(v):
		lo_hi = ['Lo', 'Hi'][v & 1]
		return f'Do{lo_hi}Subst{v >> 1}'

	rules_sbox_mix = []
	for j in range(len(subst_order)):
		# determine pre/post subst preconditions
		cur = subst_label(subst_order[j]) if j else 'DoSubst'
		nxt = subst_label(subst_order[j+1]) if (j+1) < len(subst_order) else 'DoneSubst'
		lo_hi = subst_order[j] & 1
		sub_idx = subst_order[j] >> 1
		sbox = SBOX4_1 if lo_hi else SBOX4_2
		rules_sbox_mix.append([((cur, f'State{sub_idx}^{i << (4 * lo_hi)}'), (nxt, f'Input{sub_idx}^{sbox[i] << (4 * lo_hi)}',)) for i in range(15, -1, -1)])

	rules_sbox = mix_rules(rules_sbox_mix)
else:
	####################################
	# 8-bitshuffled sbox substitution rules
	####################################

	# unfortunately these are bit too slow in run_naive.py and run_okayish.py,
	# wherease run_fast.py reveals too much info about the internal
	# structure of the chall

	subst_order = shuffled([*range(INPUT_LEN)])
	rules_sbox = [(('DoSubst',), (f'DoSubstA{subst_order[0]}', f'DoSubstBeforeSbox{subst_order[0]}'))]
	for j, i in enumerate(subst_order):
		rules_sbox += [
			((f'DoSubstB{i}',), (f'DoSubstA{i}',)),
			((f'DoSubstA{i}', f'State{i}^32'), ('SubstInput^32', f'DoSubstB{i}',)),
			((f'DoSubstA{i}', f'State{i}'), ('SubstInput', f'DoSubstB{i}',)),
			((f'DoSubstA{i}', f'DoSubstBeforeSbox{i}'), (f'DoSubstB{i}','DoOneSubst')),
			((f'DoSubstA{i}', 'SubstOutput^32'), (f'Input{i}^32', f'DoSubstB{i}',)),
			((f'DoSubstA{i}', 'SubstOutput'), (f'Input{i}', f'DoSubstB{i}',)),
		]
		if j+1 >= len(subst_order):
			rules_sbox += [((f'DoSubstA{i}', 'DoneOneSubst'), ('DoneSubst',))]
		else:
			rules_sbox += [((f'DoSubstA{i}', 'DoneOneSubst'), (f'DoSubstA{subst_order[j+1]}', f'DoSubstBeforeSbox{subst_order[j+1]}'))]

	rules_sbox += [
		(('DoOneSubst', f'SubstInput^{i}',), ('DoneOneSubst',f'SubstOutput^{SBOX8[i]}',))
		for i in range(255, -1, -1)
	]


####################################
# comparison with correct result
####################################
rules_check = [(('CheckResult1',), ('CheckResult',))]
good_p = 0

for i in range(INPUT_LEN):
	for b in range(7, -1, -1):
		b_set = (ENC_FLAG[i] & (1 << b)) != 0
		if b_set:
			good_p += 1
			rules_check += [(('CheckResult', f'Input{i}^{1 << b}',),('CheckResult1','PMatch',))]
		else:
			rules_check += [(('CheckResult', f'Input{i}^{1 << b}',),('CheckResult1','NMatch',))]

rules_check += [
	# ensure no NMatch atoms
	(('CheckResult', 'NMatch'), ()),
	# ensure exactly good_p PMatch atoms
	(('CheckResult', f'PMatch^{good_p}'), ('CheckResult2',)),
	(('CheckResult2', f'PMatch'), ()),
	(('CheckResult2',), ('Success',))
]


####################################
# cipher steps loop
####################################
rules_main = shuffled([
	(('Start',), ('S0', f'RoundTicket^{ROUND_COUNT}',)),
	(('S0', 'RoundTicket'), ('S1', 'DoAddRoundKey')),
	(('S1', 'DoneAddRoundKey'), ('S2', 'DoPerm')),
	(('S2', 'DonePerm'), ('S3', 'DoSubst')),
	(('S3', 'DoneSubst'), ('S0',)),
]) + [(('S0',), ('CheckResult',))]


####################################
# interleave rules from all steps
####################################

# note: we force mod-256 rules at the start,
# as this is a fair bit faster in run_naive.py

rules = rules_mod256
rules += mix_rules([rules_addroundkey, rules_sbox, rules_perm, rules_main, rules_check])


# output rules in multiset-rewriting format
var_set = set()
for inputs, outputs in rules:
	print(', '.join(inputs) + ' --> ' + ', '.join(outputs))
	if isinstance(inputs, str) or isinstance(outputs, str):
		print('bad rule:', inputs, outputs, file=sys.stderr)
		sys.exit(1)
	for i in inputs:
		i0 = i.partition('^')[0]
		var_set.add(i0)
	for i in outputs:
		i0 = i.partition('^')[0]
		var_set.add(i0)

print('# var count', len(var_set))
print('# rule count', len(rules))