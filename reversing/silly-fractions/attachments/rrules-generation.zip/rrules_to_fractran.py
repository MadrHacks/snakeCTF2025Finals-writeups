#!/usr/bin/env python3
# (c) 2025 rw-r-r-0644, MIT license

from dataclasses import dataclass
from sympy import nextprime
import sys
import math

sys.set_int_max_str_digits(1_000_000) 

def term_var(term):
	return term.partition('^')[0]
def term_deg(term):
	d_str = term.partition('^')[2]
	return int(d_str) if d_str != '' else 1

def update_vars(var_maxd, term_list):
	for t in term_list:
		v, d = term_var(t), term_deg(t)
		var_maxd[v] = max(var_maxd.get(v, 0), d)

def parse_ruleset(input_name):
	p_rules = []
	p_vars = {}
	with open(input_name, 'r') as f:
		for line in f:
			if line.startswith('#') or line.strip() == '':
				continue
			line = line.strip()
			raw_inp_terms, _, raw_out_terms = line.partition('-->')
			inp_terms = [t.strip() for t in raw_inp_terms.split(',') if t.strip() != '']
			out_terms = [t.strip() for t in raw_out_terms.split(',') if t.strip() != '']
			update_vars(p_vars, inp_terms + out_terms)
			p_rules.append((inp_terms, out_terms))

	return p_rules, sorted(p_vars.keys(), key=lambda k: -p_vars[k])

def write_var_map(var_map, output_name):
	with open(output_name, 'w') as f:
		for v in var_map:
			f.write(f'{var_map[v]} {v}\n')

def write_fractran_rules(p_rules, var_map, output_name):
	with open(output_name, 'w') as f:
		f.write('% just a bunch of silly fractions, nothing to see here ;3\n')
		for inp_terms, out_terms in p_rules:
			num = 1
			den = 1
			for t in inp_terms:
				v, d = term_var(t), term_deg(t)
				den *= var_map[v] ** d
			for t in out_terms:
				v, d = term_var(t), term_deg(t)
				num *= var_map[v] ** d
			assert math.gcd(num, den) == 1
			f.write(f'{num} / {den}\n')

def rrules_to_fractran(input_name, output_rules):
	# ooof everything is bad and hardcoded but good enough for now I guess
	var_map = {}

	next_p = 2
	def alloc_prime():
		nonlocal next_p
		res = next_p
		next_p = nextprime(next_p)
		return res


	INPUT_LEN = 48
	for i in range(INPUT_LEN):
		var_map[f'Input{i}'] = alloc_prime()
	var_map['Start'] = alloc_prime()
	var_map['Success'] = alloc_prime()

	c_rules, c_vars = parse_ruleset(input_name)
	for v in c_vars:
		if v not in var_map:
			var_map[v] = alloc_prime()

	write_var_map(var_map, output_rules + '.map')
	write_fractran_rules(c_rules, var_map, output_rules)

if __name__ == '__main__':
	if len(sys.argv) != 3:
		print('Usage: python rrules_to_fractran.py <input.rrules> <output_rules>')
		sys.exit(1)
	rrules_to_fractran(sys.argv[1], sys.argv[2])