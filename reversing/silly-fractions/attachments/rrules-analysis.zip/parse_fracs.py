#!/usr/bin/env python3
# (c) 2025 rw-r-r-0644, MIT license
from collections import defaultdict
from sympy import primerange, factorint
import heapq
import math
import time
import sys
import os
import subprocess

sys.set_int_max_str_digits(1_000_000)

FLAG_LEN = 48
PRIME_FACTORS = [*primerange(65536)]
PRIME_FACTORS_IDX = {p: i for i, p in enumerate(PRIME_FACTORS)}

def factor_idx(n):
	return [(PRIME_FACTORS_IDX[p], e) for p, e in factorint(n).items()]

def load_raw_fractions(filename):
	with open(filename, 'r') as input_f:
		input_l = input_f.readlines()
	fractions = []
	for line in input_l:
		if not line.startswith('%') and '/' in line:
			s_num, _, s_den = line.partition('/')
			fractions.append((int(s_num), int(s_den)))
	return fractions

# load fractions from checker.frac
checker_path = 'checker.frac'
raw_frac = load_raw_fractions(checker_path)
frac_count = len(raw_frac)

# factor each fraction numerator and denominator
num_factors = [factor_idx(num) for num, _ in raw_frac]
den_factors = [factor_idx(den) for _, den in raw_frac]

# find index of highest prime / last atom
max_prime_idx = max(pi
	for factor in num_factors + den_factors
	for pi, _ in factor)

# opt: lookup fractions with a certain atom in the numerator / denominator
den_lookup = [[] for _ in range(max_prime_idx + 1)]
num_lookup = [[] for _ in range(max_prime_idx + 1)]
for idx in range(frac_count):
	for pi, _ in den_factors[idx]:
		den_lookup[pi].append(idx)
	for pi, _ in num_factors[idx]:
		num_lookup[pi].append(idx)


# find a set of rules such that:
# - any of pre_any are in the denominator (preconditions)
# - all of pre_all are in the denominator (preconditions)
# - any of post_any are in the numerator (postconditions)
# - all of post_all are in the numerator (postconditions)
def find_rules(pre_any=[], pre_all=[], post_any=[], post_all=[]):
	# add candidates that satisfy _any conditions (ignore degree for now)
	candidates_pre_any = set() if pre_any else set(range(frac_count))
	for pi, _ in pre_any:
		candidates_pre_any.update(den_lookup[pi])
	candidates_post_any = set() if post_any else set(range(frac_count))
	for pi, _ in post_any:
		candidates_post_any.update(num_lookup[pi])
	candidates = candidates_pre_any & candidates_post_any

	# remove candidates that cannot satisfy _all conditions (ignore degree for now)
	for pi, _ in pre_all:
		candidates &= set(den_lookup[pi])
	for pi, _ in post_all:
		candidates &= set(num_lookup[pi])

	# now check degrees
	result = set()
	for idx in candidates:
		cden_factors = dict(den_factors[idx])
		cnum_factors = dict(num_factors[idx])
		good = all(cden_factors.get(pi, 0) >= e for pi, e in pre_all) \
			and all(cnum_factors.get(pi, 0) >= e for pi, e in post_all) \
			and (not pre_any) or any(cden_factors.get(pi, 0) >= e for pi, e in pre_any) \
			and (not post_any) or any(cnum_factors.get(pi, 0) >= e for pi, e in post_any)
		if good:
			result.add(idx)
	return result


# find exactly one rule matching the specified set of conditions (see above rule for info)
def find_one_rule(pre_any=[], pre_all=[], post_any=[], post_all=[]):
	rules = find_rules(pre_any, pre_all, post_any, post_all)
	assert rules and len(rules) == 1
	return rules.pop()


def term_to_str(atom, exp=1, var_names=dict()):
	atom_name = var_names.get(atom, f'var{atom}')
	return f'{atom_name}^{exp}' if exp > 1 else atom_name

def rule_to_str(rule_idx, var_names=dict()):
	pre_str = ', '.join([term_to_str(idx, exp, var_names)
		for idx, exp in den_factors[rule_idx]])
	post_str = ', '.join([term_to_str(idx, exp, var_names)
		for idx, exp in num_factors[rule_idx]])
	return pre_str + ' --> ' + post_str
