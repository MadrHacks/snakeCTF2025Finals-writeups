#!/usr/bin/env python3
# (c) 2025 rw-r-r-0644, MIT license
from parse_fracs import *

var_names = {i: f'Input{i}' for i in range(48)} | {48: 'Start', 49: 'Success'}

with open('checker.recovered.rrules', 'w') as f:
	for i in range(frac_count):
		f.write(rule_to_str(i) + '\n')