#!/usr/bin/env python3
# (c) 2025 rw-r-r-0644, MIT license
from parse_fracs import *


# these are hardcoded and we know them from run.py
S_Start = 48
S_Success = 49


# BFS to find a shortest path from start_atom to end_atom,
# ignoring all extra preconditions and postconditions
def print_path(start_atom, end_atom, avoid={}, var_names=dict()):
	pre = [None] * (max_prime_idx + 1)
	queue = [start_atom]
	while queue:
		cur = queue.pop(0)
		for tr in den_lookup[cur]:
			for nxt, _ in num_factors[tr]:
				if pre[nxt] is not None:
					continue
				pre[nxt] = cur
				queue.append(nxt)
				if nxt == end_atom:
					break

	assert pre[end_atom] is not None, "No path found!"

	cur = end_atom
	path = [cur]
	while pre[cur] != start_atom:
		cur = pre[cur]
		path.insert(0, cur)
	path.insert(0, start_atom)

	start_name = term_to_str(start_atom, 1, var_names)
	end_name = term_to_str(end_atom, 1, var_names)
	print(f'Possible len {len(path)} path from {start_name} to {end_name}')

	for i, (cur, nxt) in enumerate(zip(path, path[1:])):
		print(f'Step {i}:')
		possible_tr = find_rules(pre_any=[(cur, 1)], post_any=[(nxt, 1)])
		for tr in possible_tr:
			print(rule_to_str(tr, var_names))


# print success path
print('-'*40)
print('Success path:')
print_path(S_Start, S_Success, var_names={
	48: 'Start',
	49: 'Success',
})

# find and print cipher loop
round_count = 10
rule_start_idx = find_one_rule(pre_all=[(S_Start, 1)])

for pi, e in num_factors[rule_start_idx]:
	if e == round_count:
		S_RoundTicket = pi
	else:
		S_S0 = pi

print('-'*40)
print('Loop path:')
print_path(S_S0, S_S0, var_names={
	48: 'Start',
	49: 'Success',
	S_RoundTicket: 'RoundTicket',
	S_S0: 'S0'
})
