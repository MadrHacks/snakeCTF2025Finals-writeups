package main

import (
	"os"
	clientHTTP "treasure/client/http"
	"treasure/controller"
	"treasure/gateway"
	"treasure/handler"
	serverHTTP "treasure/server/http"

	"go.uber.org/fx"
	"go.uber.org/fx/fxevent"
	"go.uber.org/zap"
)

func main() {
	fx.New(
		// Ingress modules
		serverHTTP.Module,
		// Egress modules
		clientHTTP.Module,
		// Utility modules
		fx.Provide(
			getLogger,
		),
		fx.WithLogger(func(log *zap.Logger) fxevent.Logger {
			return &fxevent.ZapLogger{Logger: log}
		}),

		handler.Module,
		gateway.Module,
		controller.Module,
	).Run()
}

func getLogger() (*zap.Logger, error) {
	if os.Getenv("GO_ENV") == "production" {
		return zap.NewProduction()
	} else {
		return zap.NewDevelopment()
	}
}
