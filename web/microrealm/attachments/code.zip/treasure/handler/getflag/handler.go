package getflag

import (
	"encoding/json"
	"net/http"

	"treasure/controller/flag"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Handler struct {
	log            *zap.Logger
	flagController *flag.Controller
}

type HandlerParams struct {
	fx.In

	Logger         *zap.Logger
	FlagController *flag.Controller
}

func New(params HandlerParams) (*Handler, error) {
	return &Handler{
		log:            params.Logger,
		flagController: params.FlagController,
	}, nil
}

func (*Handler) Pattern() string {
	return "/get-flag"
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusOK)

	// Get token from query params
	token := r.URL.Query().Get("token")
	if token == "" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	flagValue, err := h.flagController.GetFlag(token)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		h.log.With(zap.String("token", token)).Error("failed to get flag", zap.Error(err))
		return
	}

	payload, err := json.Marshal(map[string]string{
		"flag": flagValue,
	})
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		h.log.Error("failed to marshal flag", zap.Error(err))
		return
	}

	_, err = w.Write(payload)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		h.log.Error("failed to write payload", zap.Error(err))
		return
	}
}
