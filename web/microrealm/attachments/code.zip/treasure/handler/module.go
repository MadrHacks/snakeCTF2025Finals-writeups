package handler

import (
	"treasure/handler/getflag"
	"treasure/handler/health"
	"treasure/server/http"

	"go.uber.org/fx"
)

func asHTTPRoute(f any) any {
	return fx.Annotate(
		f,
		fx.As(new(http.Route)),
		fx.ResultTags(`group:"http-routes"`),
	)
}

var Module = fx.Module("handler",
	fx.Provide(
		asHTTPRoute(getflag.New),
		asHTTPRoute(health.New),
	),
)
