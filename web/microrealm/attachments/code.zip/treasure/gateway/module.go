package gateway

import (
	"treasure/gateway/buccaneer"
	"treasure/gateway/wayfinder"

	"go.uber.org/fx"
)

var Module = fx.Module("gateway",
	fx.Provide(
		wayfinder.New,
		buccaneer.New,
	),
	fx.Invoke(func(*wayfinder.Gateway) {}),
)
