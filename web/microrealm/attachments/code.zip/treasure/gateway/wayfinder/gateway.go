package wayfinder

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"strconv"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Gateway struct {
	log        *zap.Logger
	httpClient *http.Client
}

type GatewayParams struct {
	fx.In

	Logger     *zap.Logger
	HTTPClient *http.Client
}

func New(lc fx.Lifecycle, params GatewayParams) (*Gateway, error) {
	gateway := &Gateway{
		log:        params.Logger,
		httpClient: params.HTTPClient,
	}

	// Get the host IP address
	host, err := getLocalIP()
	if err != nil || len(host) == 0 {
		return nil, errors.New("failed to get host IP address")
	}

	sm := ServiceModel{
		ServiceType: FlagService,
		IP:          host,
		Port:        8080,
	}

	lc.Append(fx.Hook{
		OnStart: func(ctx context.Context) error {
			err := gateway.RegisterService(sm)
			params.Logger.Info("Registering service with Wayfinder", zap.Any("service", sm))
			if err != nil {
				params.Logger.Error("Failed to register service with Wayfinder", zap.Any("service", sm), zap.Error(err))
				return err
			}
			return nil
		},
		OnStop: func(ctx context.Context) error {
			err := gateway.UnregisterService(sm)
			params.Logger.Info("Unregistering service from Wayfinder", zap.Any("service", sm))
			if err != nil {
				return err
			}
			return nil
		},
	})

	return gateway, nil
}

func (g *Gateway) GetService(st ServiceType) (ServiceModel, error) {
	req, err := http.NewRequest("GET", "http://wayfinder:8080/get-service", nil)
	if err != nil {
		return ServiceModel{}, err
	}

	// Add query parameters
	q := req.URL.Query()
	q.Add("service_type", string(st))
	req.URL.RawQuery = q.Encode()

	payload, err := g.httpGetRequest(*req)
	if err != nil {
		return ServiceModel{}, err
	}

	sm, err := JSONToServiceModel(payload)
	if err != nil {
		return ServiceModel{}, err
	}

	return sm, nil
}

func (g *Gateway) RegisterService(sm ServiceModel) error {
	req, err := http.NewRequest("GET", "http://wayfinder:8080/register", nil)
	if err != nil {
		return err
	}

	// Add query parameters
	queryParams := ServiceModelToQueryParams(sm)
	req.URL.RawQuery = queryParams.Encode()

	_, err = g.httpGetRequest(*req)
	if err != nil {
		return err
	}

	return nil
}

func (g *Gateway) UnregisterService(sm ServiceModel) error {
	req, err := http.NewRequest("GET", "http://wayfinder:8080/unregister", nil)
	if err != nil {
		return err
	}

	// Add query parameters
	queryParams := ServiceModelToQueryParams(sm)
	req.URL.RawQuery = queryParams.Encode()

	_, err = g.httpGetRequest(*req)
	if err != nil {
		return err
	}

	return nil
}

func (g *Gateway) httpGetRequest(req http.Request) ([]byte, error) {
	g.log.Debug("Sending request to Wayfinder", zap.String("url", req.URL.String()))
	res, err := g.httpClient.Get(req.URL.String())
	if err != nil {
		return nil, err
	}

	if res.StatusCode != http.StatusOK {
		return nil, errors.New("invalid response from Wayfinder, status code: " + strconv.Itoa(res.StatusCode))
	}

	// Parse the response body to extract the service model
	defer res.Body.Close()
	payload, err := io.ReadAll(res.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	return payload, nil
}

func getLocalIP() (string, error) {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return "", errors.New("failed to get local IP address")
	}
	for _, address := range addrs {
		if ipnet, ok := address.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
			if ipnet.IP.To4() != nil {
				return ipnet.IP.String(), nil
			}
		}
	}
	return "", errors.New("failed to get local IP address")
}
