package buccaneer

import (
	"errors"
	"fmt"
	"io"
	"net/http"
	"strconv"

	"treasure/gateway/wayfinder"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

// Gateway defines the interface for interacting with the Buccaneer service
type Gateway interface {
	GetUser(token string) (User, error)
}

// GatewayImpl implements the Gateway interface
type GatewayImpl struct {
	log        *zap.Logger
	httpClient *http.Client

	wayfinderGateway *wayfinder.Gateway
}

type GatewayParams struct {
	fx.In

	Logger           *zap.Logger
	HTTPClient       *http.Client
	WayfinderGateway *wayfinder.Gateway
}

func New(params GatewayParams) (Gateway, error) {
	gateway := &GatewayImpl{
		log:              params.Logger,
		httpClient:       params.HTTPClient,
		wayfinderGateway: params.WayfinderGateway,
	}

	return gateway, nil
}

func (g *GatewayImpl) GetUser(token string) (User, error) {
	sm, err := g.wayfinderGateway.GetService(wayfinder.AuthService)
	if err != nil {
		return User{}, err
	}

	portStr := strconv.Itoa(sm.Port)

	//goland:noinspection HttpUrlsUsage
	req, err := http.NewRequest("GET", "http://"+sm.IP+":"+portStr+"/verify-token", nil)
	if err != nil {
		return User{}, err
	}

	queryParams := req.URL.Query()
	queryParams.Add("token", token)
	req.URL.RawQuery = queryParams.Encode()

	payload, err := g.httpGetRequest(*req)
	if err != nil {
		return User{}, err
	}

	user, err := JSONToUser(payload)
	if err != nil {
		return User{}, err
	}

	return user, nil
}

func (g *GatewayImpl) httpGetRequest(req http.Request) ([]byte, error) {
	g.log.Debug("Sending request to Buccaneer", zap.String("url", req.URL.String()))
	res, err := g.httpClient.Get(req.URL.String())
	if err != nil {
		return nil, err
	}

	if res.StatusCode != http.StatusOK {
		return nil, errors.New("invalid response from Buccaneer")
	}

	// Parse the response body to extract the service model
	defer res.Body.Close()
	payload, err := io.ReadAll(res.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	return payload, nil
}
