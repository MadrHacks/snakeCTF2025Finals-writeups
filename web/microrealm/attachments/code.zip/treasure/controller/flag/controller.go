package flag

import (
	"errors"
	"fmt"
	"os"

	"treasure/gateway/buccaneer"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Controller struct {
	log *zap.Logger

	buccaneerGateway buccaneer.Gateway
}

type ControllerParams struct {
	fx.In

	Logger           *zap.Logger
	BuccaneerGateway buccaneer.Gateway
}

func New(params ControllerParams) (*Controller, error) {
	return &Controller{
		log:              params.Logger,
		buccaneerGateway: params.BuccaneerGateway,
	}, nil
}

func (c *Controller) GetFlag(token string) (string, error) {
	// Check if userphoto is admin
	user, err := c.buccaneerGateway.GetUser(token)
	if err != nil {
		return "", errors.New("unauthorized: admin access required")
	}
	if !user.IsAdmin {
		return "", errors.New(fmt.Sprintf("unauthorized: admin access required (userphoto id %d)", user.ID))
	}

	flag := os.Getenv("FLAG")
	if flag == "" {
		return "", errors.New("FLAG environment variable not set")
	}

	// Retrieve the flag from environment variable
	return os.Getenv("FLAG"), nil
}
