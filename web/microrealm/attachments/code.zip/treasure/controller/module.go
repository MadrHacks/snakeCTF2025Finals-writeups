package controller

import (
	"treasure/controller/flag"

	"go.uber.org/fx"
)

var Module = fx.Module("controller",
	fx.Provide(
		flag.New,
	),
)
