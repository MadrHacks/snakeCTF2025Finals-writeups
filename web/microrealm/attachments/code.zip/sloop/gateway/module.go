package gateway

import (
	"sloop/gateway/buccaneer"
	"sloop/gateway/treasure"
	"sloop/gateway/wayfinder"

	"go.uber.org/fx"
)

var Module = fx.Module("gateway",
	fx.Provide(
		wayfinder.New,
		treasure.New,
		buccaneer.New,
	),
)
