package wayfinder

import (
	"errors"
	"fmt"
	"io"
	"net/http"
	"strconv"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Gateway struct {
	log        *zap.Logger
	httpClient *http.Client
}

type GatewayParams struct {
	fx.In

	Logger     *zap.Logger
	HTTPClient *http.Client
}

func New(params GatewayParams) (*Gateway, error) {
	gateway := &Gateway{
		log:        params.Logger,
		httpClient: params.HTTPClient,
	}

	return gateway, nil
}

func (g *Gateway) GetService(st ServiceType) (ServiceModel, error) {
	req, err := http.NewRequest("GET", "http://wayfinder:8080/get-service", nil)
	if err != nil {
		return ServiceModel{}, err
	}

	// Add query parameters
	q := req.URL.Query()
	q.Add("service_type", string(st))
	req.URL.RawQuery = q.Encode()

	payload, err := g.httpGetRequest(*req)
	if err != nil {
		return ServiceModel{}, err
	}

	sm, err := JSONToServiceModel(payload)
	if err != nil {
		return ServiceModel{}, err
	}

	return sm, nil
}

func (g *Gateway) RegisterService(sm ServiceModel) error {
	req, err := http.NewRequest("GET", "http://wayfinder:8080/register", nil)
	if err != nil {
		return err
	}

	// Add query parameters
	queryParams := ServiceModelToQueryParams(sm)
	req.URL.RawQuery = queryParams.Encode()

	_, err = g.httpGetRequest(*req)
	if err != nil {
		return err
	}

	return nil
}

func (g *Gateway) UnregisterService(sm ServiceModel) error {
	req, err := http.NewRequest("GET", "http://wayfinder:8080/unregister", nil)
	if err != nil {
		return err
	}

	// Add query parameters
	queryParams := ServiceModelToQueryParams(sm)
	req.URL.RawQuery = queryParams.Encode()

	_, err = g.httpGetRequest(*req)
	if err != nil {
		return err
	}

	return nil
}

func (g *Gateway) httpGetRequest(req http.Request) ([]byte, error) {
	g.log.Debug("Sending request to Wayfinder", zap.String("url", req.URL.String()))
	res, err := g.httpClient.Get(req.URL.String())
	if err != nil {
		g.log.Error("failed to send request to Wayfinder", zap.Error(err))
		return nil, err
	}

	if res.StatusCode != http.StatusOK {
		return nil, errors.New("invalid response from Wayfinder, status code: " + strconv.Itoa(res.StatusCode))
	}

	// Parse the response body to extract the service model
	defer res.Body.Close()
	payload, err := io.ReadAll(res.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	return payload, nil
}
