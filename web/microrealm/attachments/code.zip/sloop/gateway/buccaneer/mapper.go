package buccaneer

import (
	"encoding/json"
	"fmt"
)

func JSONToUser(data []byte) (User, error) {
	var u User
	err := json.Unmarshal(data, &u)
	if err != nil {
		return User{}, fmt.Errorf("failed to unmarshal JSON to service model: %w", err)
	}

	return u, nil
}
