package buccaneer

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strconv"

	"sloop/gateway/wayfinder"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Gateway struct {
	log        *zap.Logger
	httpClient *http.Client

	wayfinderGateway *wayfinder.Gateway
}

type GatewayParams struct {
	fx.In

	Logger           *zap.Logger
	HTTPClient       *http.Client
	WayfinderGateway *wayfinder.Gateway
}

func New(params GatewayParams) (*Gateway, error) {
	gateway := &Gateway{
		log:              params.Logger,
		httpClient:       params.HTTPClient,
		wayfinderGateway: params.WayfinderGateway,
	}

	return gateway, nil
}

func (g *Gateway) GetUser(token string) (User, error) {
	sm, err := g.wayfinderGateway.GetService(wayfinder.AuthService)
	if err != nil {
		return User{}, err
	}

	portStr := strconv.Itoa(sm.Port)

	//goland:noinspection HttpUrlsUsage
	req, err := http.NewRequest("GET", "http://"+sm.IP+":"+portStr+"/verify-token", nil)
	if err != nil {
		return User{}, err
	}

	queryParams := req.URL.Query()
	queryParams.Add("token", token)
	req.URL.RawQuery = queryParams.Encode()

	payload, err := g.httpGetRequest(*req)
	if err != nil {
		return User{}, err
	}

	user, err := JSONToUser(payload)
	if err != nil {
		return User{}, err
	}

	return user, nil
}

func (g *Gateway) Login(userInput UserInput) (string, error) {
	sm, err := g.wayfinderGateway.GetService(wayfinder.AuthService)
	if err != nil {
		return "", err
	}

	portStr := strconv.Itoa(sm.Port)

	//goland:noinspection HttpUrlsUsage
	req, err := http.NewRequest("GET", "http://"+sm.IP+":"+portStr+"/login", nil)
	if err != nil {
		return "", err
	}

	q := req.URL.Query()
	q.Add("username", userInput.Username)
	q.Add("password", userInput.Password)
	req.URL.RawQuery = q.Encode()

	payload, err := g.httpGetRequest(*req)
	if err != nil {
		return "", err
	}

	// expected JSON: {"token":"..."}
	type tokenResp struct {
		Token string `json:"token"`
	}
	var tr tokenResp
	if err := json.Unmarshal(payload, &tr); err != nil {
		return "", err
	}
	return tr.Token, nil
}

func (g *Gateway) Register(userInput UserInput) (string, error) {
	sm, err := g.wayfinderGateway.GetService(wayfinder.AuthService)
	if err != nil {
		return "", err
	}

	portStr := strconv.Itoa(sm.Port)

	//goland:noinspection HttpUrlsUsage
	req, err := http.NewRequest("GET", "http://"+sm.IP+":"+portStr+"/register", nil)
	if err != nil {
		return "", err
	}

	q := req.URL.Query()
	q.Add("username", userInput.Username)
	q.Add("password", userInput.Password)
	req.URL.RawQuery = q.Encode()

	payload, err := g.httpGetRequest(*req)
	if err != nil {
		return "", err
	}

	type tokenResp struct {
		Token string `json:"token"`
	}
	var tr tokenResp
	if err := json.Unmarshal(payload, &tr); err != nil {
		return "", err
	}
	return tr.Token, nil
}

func (g *Gateway) httpGetRequest(req http.Request) ([]byte, error) {
	g.log.Debug("Sending request to Buccaneer", zap.String("url", req.URL.String()))
	res, err := g.httpClient.Get(req.URL.String())
	if err != nil {
		g.log.Error("failed to send request to Buccaneer", zap.Error(err))
		return nil, err
	}

	if res.StatusCode != http.StatusOK {
		return nil, errors.New("invalid response from Buccaneer")
	}

	// Parse the response body to extract the service model
	defer res.Body.Close()
	payload, err := io.ReadAll(res.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	return payload, nil
}
