package treasure

import (
	"errors"
	"fmt"
	"io"
	"net/http"
	"strconv"

	"sloop/gateway/wayfinder"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Gateway struct {
	log        *zap.Logger
	httpClient *http.Client

	wayfinderGateway *wayfinder.Gateway
}

type GatewayParams struct {
	fx.In

	Logger           *zap.Logger
	HTTPClient       *http.Client
	WayfinderGateway *wayfinder.Gateway
}

func New(params GatewayParams) (*Gateway, error) {
	gateway := &Gateway{
		log:              params.Logger,
		httpClient:       params.HTTPClient,
		wayfinderGateway: params.WayfinderGateway,
	}

	return gateway, nil
}

func (g *Gateway) GetFlag(token string) (string, error) {
	sm, err := g.wayfinderGateway.GetService(wayfinder.FlagService)
	if err != nil {
		return "", err
	}

	portStr := strconv.Itoa(sm.Port)

	//goland:noinspection HttpUrlsUsage
	req, err := http.NewRequest("GET", "http://"+sm.IP+":"+portStr+"/get-flag", nil)
	if err != nil {
		return "", err
	}

	queryParams := req.URL.Query()
	queryParams.Add("token", token)
	req.URL.RawQuery = queryParams.Encode()

	payload, err := g.httpGetRequest(*req)
	if err != nil {
		return "", err
	}
	flag := string(payload)

	return flag, nil
}

func (g *Gateway) httpGetRequest(req http.Request) ([]byte, error) {
	g.log.Debug("Sending request to Treasure", zap.String("url", req.URL.String()))
	res, err := g.httpClient.Get(req.URL.String())
	if err != nil {
		return nil, err
	}

	if res.StatusCode != http.StatusOK {
		g.log.Error("invalid response from Treasure", zap.Int("status", res.StatusCode))
		return nil, errors.New("invalid response from Treasure")
	}

	// Parse the response body to extract the service model
	defer res.Body.Close()
	payload, err := io.ReadAll(res.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	return payload, nil
}
