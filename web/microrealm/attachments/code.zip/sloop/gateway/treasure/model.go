package treasure

type Token string
