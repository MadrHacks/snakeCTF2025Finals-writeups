package getuserphoto

import (
    "net/http"
    "strconv"
    "strings"

    "sloop/controller/photo"

    "go.uber.org/fx"
    "go.uber.org/zap"
)

type Handler struct {
	log        *zap.Logger
	controller *photo.Controller
}

type HandlerParams struct {
	fx.In

	Logger     *zap.Logger
	Controller *photo.Controller
}

func New(params HandlerParams) (*Handler, error) {
	return &Handler{
		log:        params.Logger,
		controller: params.Controller,
	}, nil
}

func (*Handler) Pattern() string {
	return "/get-user-photo"
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}

	// Extract token from Authorization header
	authHeader := r.Header.Get("Authorization")
	if authHeader == "" {
		h.log.Error("Missing Authorization header")
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	// Expected format: "Bearer <token>"
	parts := strings.Split(authHeader, " ")
	if len(parts) != 2 || parts[0] != "Bearer" {
		h.log.Error("Invalid Authorization header format")
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	token := parts[1]

	photoData, err := h.controller.GetUserPhoto(token)
	if err != nil {
		h.log.Warn("Failed to get user photo")
		w.WriteHeader(http.StatusNotFound)
		return
	}
    photoDataLen := len(photoData)

	// Set appropriate content type based on the image data
	// This is a simplification - in a real app, you'd detect the actual image type
	w.Header().Set("Content-Type", "image/jpeg")
	w.Header().Set("Content-Length", strconv.Itoa(photoDataLen))
	w.WriteHeader(http.StatusOK)
	_, err = w.Write(photoData)
	if err != nil {
		h.log.Error("Failed to write response", zap.Error(err))
	}
}
