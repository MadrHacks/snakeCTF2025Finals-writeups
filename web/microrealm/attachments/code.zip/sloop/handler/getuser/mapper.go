package getuser

// GetUserResponse represents the response body for the get-user endpoint
type GetUserResponse struct {
	ID       int    `json:"id"`
	Username string `json:"username"`
	IsAdmin  bool   `json:"is_admin"`
}
