package getuser

import (
	"encoding/json"
	"net/http"
	"sloop/controller/auth"
	"strings"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Handler struct {
	log        *zap.Logger
	controller *auth.Controller
}

type HandlerParams struct {
	fx.In

	Logger     *zap.Logger
	Controller *auth.Controller
}

func New(params HandlerParams) (*Handler, error) {
	return &Handler{
		log:        params.Logger,
		controller: params.Controller,
	}, nil
}

func (*Handler) Pattern() string {
	return "/get-user"
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}

	// Extract token from Authorization header
	authHeader := r.Header.Get("Authorization")
	if authHeader == "" {
		h.log.Error("Missing Authorization header")
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	// Expected format: "Bearer <token>"
	parts := strings.Split(authHeader, " ")
	if len(parts) != 2 || parts[0] != "Bearer" {
		h.log.Error("Invalid Authorization header format")
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	token := parts[1]

	user, err := h.controller.GetUser(token)
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	resp := GetUserResponse{
		ID:       user.ID,
		Username: user.Username,
		IsAdmin:  user.IsAdmin,
	}

	w.Header().Set("Content-Type", "application/json")
	if err := json.NewEncoder(w).Encode(resp); err != nil {
		h.log.Error("Failed to encode response", zap.Error(err))
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
}
