package setuserphoto

import (
	"encoding/json"
	"net/http"
	"sloop/controller/photo"
	"strings"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Handler struct {
	log        *zap.Logger
	controller *photo.Controller
}

type HandlerParams struct {
	fx.In

	Logger     *zap.Logger
	Controller *photo.Controller
}

func New(params HandlerParams) (*Handler, error) {
	return &Handler{
		log:        params.Logger,
		controller: params.Controller,
	}, nil
}

func (*Handler) Pattern() string {
	return "/set-user-photo"
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}

	// Extract token from Authorization header
	authHeader := r.Header.Get("Authorization")
	if authHeader == "" {
		h.log.Error("Missing Authorization header")
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	// Expected format: "Bearer <token>"
	parts := strings.Split(authHeader, " ")
	if len(parts) != 2 || parts[0] != "Bearer" {
		h.log.Error("Invalid Authorization header format")
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	token := parts[1]

	var req SetUserPhotoRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		h.log.Error("Failed to decode request", zap.Error(err))
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	if req.PhotoURL == "" {
		h.log.Error("Missing photo URL")
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	status, err := h.controller.SetUserPhoto(token, req.PhotoURL)
	if err != nil {
		h.log.Error("Failed to set user photo", zap.Error(err))
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	resp := SetUserPhotoResponse{
		Status: status,
	}

	w.Header().Set("Content-Type", "application/json")
	if err := json.NewEncoder(w).Encode(resp); err != nil {
		h.log.Error("Failed to encode response", zap.Error(err))
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
}
