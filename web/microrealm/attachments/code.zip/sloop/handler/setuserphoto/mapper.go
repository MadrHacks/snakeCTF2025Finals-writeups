package setuserphoto

// SetUserPhotoRequest represents the request body for the set-user-photo endpoint
type SetUserPhotoRequest struct {
	PhotoURL string `json:"photo_url"`
}

// SetUserPhotoResponse represents the response body for the set-user-photo endpoint
type SetUserPhotoResponse struct {
	Status string `json:"status"`
}
