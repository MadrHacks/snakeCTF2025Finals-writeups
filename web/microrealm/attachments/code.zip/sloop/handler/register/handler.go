package register

import (
	"encoding/json"
	"net/http"
	"sloop/controller/auth"
	"sloop/gateway/buccaneer"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Handler struct {
	log        *zap.Logger
	controller *auth.Controller
}

type HandlerParams struct {
	fx.In

	Logger     *zap.Logger
	Controller *auth.Controller
}

func New(params HandlerParams) (*Handler, error) {
	return &Handler{
		log:        params.Logger,
		controller: params.Controller,
	}, nil
}

func (*Handler) Pattern() string {
	return "/register"
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}

	var req RegisterRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		h.log.Error("Failed to decode request", zap.Error(err))
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	userInput := buccaneer.UserInput{
		Username: req.Username,
		Password: req.Password,
	}

	token, err := h.controller.Register(userInput)
	if err != nil {
		h.log.Error("Failed to register user", zap.Error(err))
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	resp := RegisterResponse{
		Token: token,
	}

	w.Header().Set("Content-Type", "application/json")
	err = json.NewEncoder(w).Encode(resp)
	if err != nil {
		h.log.Error("Failed to encode response", zap.Error(err))
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
}
