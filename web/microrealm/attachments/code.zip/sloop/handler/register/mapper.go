package register

// RegisterRequest represents the request body for the register endpoint
type RegisterRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

// RegisterResponse represents the response body for the register endpoint
type RegisterResponse struct {
	Token string `json:"token"`
}
