package getflag

// GetFlagResponse represents the response body for the get-flag endpoint
type GetFlagResponse struct {
	Flag string `json:"flag"`
}
