package login

// LoginRequest represents the request body for the login endpoint
type LoginRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

// LoginResponse represents the response body for the login endpoint
type LoginResponse struct {
	Token string `json:"token"`
}
