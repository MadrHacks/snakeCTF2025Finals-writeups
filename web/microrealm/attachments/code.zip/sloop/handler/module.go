package handler

import (
	"sloop/handler/getflag"
	"sloop/handler/getuser"
	"sloop/handler/getuserphoto"
	"sloop/handler/health"
	"sloop/handler/login"
	"sloop/handler/register"
	"sloop/handler/setuserphoto"
	"sloop/server/http"

	"go.uber.org/fx"
)

func asHTTPRoute(f any) any {
	return fx.Annotate(
		f,
		fx.As(new(http.Route)),
		fx.ResultTags(`group:"http-routes"`),
	)
}

var Module = fx.Module("handler",
	fx.Provide(
		asHTTPRoute(setuserphoto.New),
		asHTTPRoute(getuserphoto.New),
		asHTTPRoute(getuser.New),
		asHTTPRoute(login.New),
		asHTTPRoute(register.New),
		asHTTPRoute(getflag.New),
		asHTTPRoute(health.New),
	),
)
