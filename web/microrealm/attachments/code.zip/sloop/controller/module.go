package controller

import (
	"sloop/controller/auth"
	"sloop/controller/getflag"
	"sloop/controller/photo"

	"go.uber.org/fx"
)

var Module = fx.Module("controller",
	fx.Provide(
		photo.New,
		auth.New,
		getflag.New,
	),
)
