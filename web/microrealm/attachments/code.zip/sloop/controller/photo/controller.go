package photo

import (
	"errors"
	"io"
	"net/http"
	"sync"

	"sloop/gateway/buccaneer"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Controller struct {
	log *zap.Logger
	bg  *buccaneer.Gateway
	hc  *http.Client

	mu    sync.RWMutex
	store map[int][]byte // userID -> photo bytes
}

type ControllerParams struct {
	fx.In

	Logger           *zap.Logger
	BuccaneerGateway *buccaneer.Gateway
	HTTPClient       *http.Client
}

func New(params ControllerParams) (*Controller, error) {
	return &Controller{
		log:   params.Logger,
		bg:    params.BuccaneerGateway,
		hc:    params.HTTPClient,
		store: make(map[int][]byte),
	}, nil
}

func (c *Controller) SetUserPhoto(token string, photoURL string) (string, error) {
	// verify token and get user
	user, err := c.bg.GetUser(token)
	if err != nil {
		return "", err
	}

	c.log.Info("Downloading user photo from", zap.String("url", photoURL))
	resp, err := c.hc.Get(photoURL)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return "", errors.New("failed to download photo")
	}

	// limit read size to 500KB
	limited := io.LimitedReader{R: resp.Body, N: 500 * 1024}
	data, err := io.ReadAll(&limited)
	if err != nil {
		return "", err
	}

	c.mu.Lock()
	c.store[user.ID] = data
	c.mu.Unlock()

	return "ok", nil
}

func (c *Controller) GetUserPhoto(token string) ([]byte, error) {
	user, err := c.bg.GetUser(token)
	if err != nil {
		return nil, err
	}
	c.mu.RLock()
	defer c.mu.RUnlock()
	if b, ok := c.store[user.ID]; ok {
		return b, nil
	}
	return nil, errors.New("not found")
}
