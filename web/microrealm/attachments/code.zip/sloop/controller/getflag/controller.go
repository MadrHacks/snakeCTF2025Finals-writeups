package getflag

import (
	"sloop/gateway/treasure"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Controller struct {
	log *zap.Logger
	tg  *treasure.Gateway
}

type ControllerParams struct {
	fx.In

	Logger          *zap.Logger
	TreasureGateway *treasure.Gateway
}

func New(params ControllerParams) (*Controller, error) {
	return &Controller{
		log: params.Logger,
		tg:  params.TreasureGateway,
	}, nil
}

func (c *Controller) GetFlag(token string) (string, error) {
	return c.tg.GetFlag(token)
}
