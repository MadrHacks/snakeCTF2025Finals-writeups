package auth

import (
	"sloop/gateway/buccaneer"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Controller struct {
	log *zap.Logger
	bg  *buccaneer.Gateway
}

type ControllerParams struct {
	fx.In

	Logger           *zap.Logger
	BuccaneerGateway *buccaneer.Gateway
}

func New(params ControllerParams) (*Controller, error) {
	return &Controller{
		log: params.Logger,
		bg:  params.BuccaneerGateway,
	}, nil
}

func (c *Controller) Register(userInput buccaneer.UserInput) (string, error) {
	token, err := c.bg.Register(userInput)
	if err != nil {
		return "", err
	}
	return token, nil
}

func (c *Controller) Login(userInput buccaneer.UserInput) (string, error) {
	token, err := c.bg.Login(userInput)
	if err != nil {
		return "", err
	}
	return token, nil
}

func (c *Controller) GetUser(token string) (buccaneer.User, error) {
	user, err := c.bg.GetUser(token)
	if err != nil {
		return buccaneer.User{}, err
	}
	return user, nil
}
