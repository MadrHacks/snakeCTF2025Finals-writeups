# Harbor - Web Frontend

Harbor is the user-facing web frontend for the Microrealm microservices challenge. It provides an HTML interface for users to interact with the distributed system.

## Overview

Harbor is built with FastAPI and Jinja2 templates, providing a traditional web application interface that communicates with the Sloop API gateway to access backend microservices.

## Features

- **User Registration**: Create new user accounts
- **User Login**: Authenticate and receive session cookies
- **Profile View**: Display user information
- **Flag Retrieval**: Access the challenge flag (admin users only)
- **Session Management**: Cookie-based authentication with the backend

## Architecture

```
Browser <-> Harbor (FastAPI) <-> Sloop (API Gateway) <-> Backend Services
```

Harbor acts as a presentation layer, translating user interactions into API calls to the Sloop service.

## Components

### Main Application (`app.py`)

- FastAPI application with session middleware
- Route handlers for all user-facing pages
- Cookie-based authentication management
- HTML template rendering

### Sloop Gateway Client (`sloop.py`)

- HTTP client for communicating with the Sloop API
- Methods for login, register, user info, and flag retrieval
- Error handling and response parsing

### User Service (`user.py`)

- Profile service for retrieving user information
- Integrates with Sloop gateway

### Templates (`templates/`)

- `base.html`: Base template with common layout
- `login.html`: Login page
- `register.html`: Registration page
- `profile.html`: User profile display
- `flag.html`: Flag display page

### Static Assets (`static/`)

- `style.css`: Application styling

## Configuration

Harbor uses environment variables for configuration:

- `SLOOP_URL`: URL of the Sloop API gateway (default: `http://sloop:8080`)
- `AUTH_COOKIE_NAME`: Name of the authentication cookie (default: `token`)
- `SESSION_SECRET`: Secret key for session middleware (default: `dev-secret`)

## Running Locally

### With Docker Compose (Recommended)

```bash
docker compose up harbor
```

### Standalone Development

1. Install dependencies:

   ```bash
   cd harbor
   uv sync
   ```

2. Run the application:

   ```bash
   uv run uvicorn harbor.app:app --reload --port 5000
   ```

3. Access at: <http://localhost:5000>

### Requirements

- Python 3.11+
- uv (package manager)
- Dependencies listed in `pyproject.toml`

## API Integration

Harbor communicates with Sloop through the following endpoints:

- `POST /login`: User authentication
- `POST /register`: New user registration
- `GET /getuser`: Retrieve user information
- `GET /getflag`: Retrieve challenge flag

## Security Notes

This is a CTF challenge application with intentional vulnerabilities. The security model includes:

- Cookie-based session management
- Token validation through backend services
- No direct database access (all through API gateway)

**Do not use this code in production environments.**

## Development

### File Structure

```
harbor/
├── harbor/
│   ├── __init__.py
│   ├── __main__.py      # Entry point
│   ├── app.py           # Main application
│   ├── sloop.py         # Sloop API client
│   ├── user.py          # User service
│   ├── static/
│   │   └── style.css
│   └── templates/
│       ├── base.html
│       ├── login.html
│       ├── register.html
│       ├── profile.html
│       └── flag.html
├── pyproject.toml       # Project configuration
├── Dockerfile
└── README.md           # This file
```

### Adding New Pages

1. Create a new template in `templates/`
2. Add a route handler in `app.py`
3. Update the navigation in `base.html` if needed

### Styling

CSS is located in `static/style.css`. The application uses a simple, modern design with a pirate/nautical theme.

## Troubleshooting

- **Cannot connect to Sloop**: Verify `SLOOP_URL` environment variable and network connectivity
- **Template not found**: Ensure templates directory path is correct in `app.py`
- **Session issues**: Check `SESSION_SECRET` is set and cookies are enabled in browser
- **Dependencies missing**: Run `uv sync` to install all required packages

## Contributing

When modifying Harbor:

1. Keep templates simple and maintainable
2. Follow FastAPI best practices
3. Update this README if adding new features
4. Test with the full docker-compose stack
5. Run `ruff format` and `ruff check` before committing
