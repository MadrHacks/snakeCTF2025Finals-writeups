from typing import Any, Dict

from harbor.sloop import SloopGateway


class ProfileService:
    """Business logic for assembling user profile info."""

    def __init__(self, gateway: SloopGateway) -> None:
        self.gateway = gateway

    async def fetch_user_and_photo(self, token: str) -> Dict[str, Any]:
        user = await self.gateway.verify_token(token)
        photo_url = None
        content, mime = await self.gateway.get_user_photo(token)
        if content and mime:
            import base64

            b64 = base64.b64encode(content).decode("ascii")
            photo_url = f"data:{mime};base64,{b64}"
        return {"user": user, "photo_url": photo_url}
