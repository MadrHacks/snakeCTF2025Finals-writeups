import logging
from typing import Any, Dict, Optional, Tuple

import httpx

log = logging.getLogger(__name__)


class SloopGateway:
    """Gateway responsible for talking to Sloop backend service."""

    def __init__(self, base_url: str, timeout: float = 10.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    async def _client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(timeout=self.timeout)

    async def login(self, username: str, password: str) -> str:
        async with await self._client() as client:
            r = await client.post(
                f"{self.base_url}/login",
                json={"username": username, "password": password},
            )
            r.raise_for_status()
            data = r.json()
            token = data.get("token")
            if not token:
                raise RuntimeError("Missing token from backend")
            return token

    async def register(self, username: str, password: str) -> str:
        async with await self._client() as client:
            r = await client.post(
                f"{self.base_url}/register",
                json={"username": username, "password": password},
            )
            r.raise_for_status()
            data = r.json()
            token = data.get("token")
            if not token:
                raise RuntimeError("Missing token from backend")
            return token

    async def get_user(self, token: str) -> Optional[Dict[str, Any]]:
        """Get user information for the authenticated user."""
        async with await self._client() as client:
            r = await client.get(
                f"{self.base_url}/get-user",
                headers={"Authorization": f"Bearer {token}"},
            )
            r.raise_for_status()
            if r.status_code == 200:
                return r.json()

        return None

    async def verify_token(self, token: str) -> Optional[Dict[str, Any]]:
        """Legacy method - use get_user instead."""
        return await self.get_user(token)

    async def get_user_photo(self, token: str) -> Tuple[Optional[bytes], Optional[str]]:
        async with await self._client() as client:
            r = await client.get(
                f"{self.base_url}/get-user-photo",
                headers={"Authorization": f"Bearer {token}"},
            )
            try:
                r.raise_for_status()
            except httpx.HTTPStatusError:
                if r.status_code == 401:
                    return None, None
                if r.status_code == 404:
                    return None, None
                log.warning("Failed to fetch user photo", exc_info=r)
                return None, None
            if r.status_code == 200 and r.headers.get("content-type", "").startswith(
                "image"
            ):
                return r.content, r.headers.get("content-type", "image/jpeg")
        return None, None

    async def set_user_photo(self, token: str, url: str) -> None:
        async with await self._client() as client:
            r = await client.post(
                f"{self.base_url}/set-user-photo",
                headers={"Authorization": f"Bearer {token}"},
                json={"photo_url": url},
            )
            r.raise_for_status()

    async def get_flag(self, token: str) -> Optional[str]:
        """Get the flag for the authenticated user."""
        async with await self._client() as client:
            r = await client.get(
                f"{self.base_url}/get-flag",
                headers={"Authorization": f"Bearer {token}"},
            )
            r.raise_for_status()
            if r.status_code == 200:
                data = r.json()
                return data.get("flag")
        return None
