import logging
import os
from typing import Optional

import httpx
from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from starlette.templating import Jinja2Templates

from harbor.sloop import SloopGateway
from harbor.user import ProfileService

SLOOP_URL = os.getenv("SLOOP_URL", "http://sloop:8080")
COOKIE_NAME = os.getenv("AUTH_COOKIE_NAME", "token")


log = logging.getLogger(__name__)


class AuthCookie:
    """Encapsulates cookie handling for auth token."""

    def __init__(self, cookie_name: str = COOKIE_NAME) -> None:
        self.cookie_name = cookie_name

    def get_token(self, request: Request) -> Optional[str]:
        return request.cookies.get(self.cookie_name)

    def set_token(self, response: RedirectResponse, token: str) -> None:
        response.set_cookie(self.cookie_name, token, httponly=True, samesite="lax")

    def clear(self, response: RedirectResponse) -> None:
        response.delete_cookie(self.cookie_name)


class HarborApp:
    def __init__(self) -> None:
        self.app = FastAPI(title="Harbor Frontend")
        base_dir = os.path.dirname(__file__)
        self.templates = Jinja2Templates(directory=os.path.join(base_dir, "templates"))
        static_dir = os.path.join(base_dir, "static")

        self.app.mount("/static", StaticFiles(directory=static_dir), name="static")
        self.app.add_middleware(
            SessionMiddleware, secret_key=os.getenv("SESSION_SECRET", "dev-secret")
        )

        # dependencies
        self.cookie = AuthCookie(COOKIE_NAME)
        self.gateway = SloopGateway(SLOOP_URL)
        self.profile = ProfileService(self.gateway)

        # routes
        self._register_routes()

    def _register_routes(self) -> None:
        app = self.app
        templates = self.templates
        cookie = self.cookie
        profile = self.profile
        gateway = self.gateway

        @app.get("/", response_class=HTMLResponse)
        async def root(request: Request):
            token = cookie.get_token(request)
            if not token:
                return RedirectResponse(url="/login", status_code=302)
            return RedirectResponse(url="/profile", status_code=302)

        @app.get("/login", response_class=HTMLResponse)
        async def login_page(request: Request):
            token = cookie.get_token(request)
            if token:
                return RedirectResponse(url="/profile", status_code=302)
            return templates.TemplateResponse(
                "login.html", {"request": request, "error": None}
            )

        @app.post("/login")
        async def login(
            request: Request, username: str = Form(...), password: str = Form(...)
        ):
            try:
                token = await gateway.login(username, password)
            except Exception as e:
                return templates.TemplateResponse(
                    "login.html", {"request": request, "error": str(e)}, status_code=400
                )
            resp = RedirectResponse(url="/profile", status_code=302)
            cookie.set_token(resp, token)
            return resp

        @app.get("/register", response_class=HTMLResponse)
        async def register_page(request: Request):
            token = cookie.get_token(request)
            if token:
                return RedirectResponse(url="/profile", status_code=302)
            return templates.TemplateResponse(
                "register.html", {"request": request, "error": None}
            )

        @app.post("/register")
        async def register(
            request: Request, username: str = Form(...), password: str = Form(...)
        ):
            try:
                token = await gateway.register(username, password)
            except Exception as e:
                return templates.TemplateResponse(
                    "register.html",
                    {"request": request, "error": str(e)},
                    status_code=400,
                )
            resp = RedirectResponse(url="/profile", status_code=302)
            cookie.set_token(resp, token)
            return resp

        @app.get("/profile", response_class=HTMLResponse)
        async def profile_page(request: Request):
            token = cookie.get_token(request)

            if not token:
                return RedirectResponse(url="/login", status_code=302)

            try:
                info = await profile.fetch_user_and_photo(token)
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 401:
                    logging.warning("Invalid token, logging out user")
                else:
                    logging.error("Unexpected error fetching user info", exc_info=e)
                return RedirectResponse(url="/logout", status_code=302)
            return templates.TemplateResponse(
                "profile.html",
                {
                    "request": request,
                    "user": info.get("user"),
                    "photo_url": info.get("photo_url"),
                    "message": None,
                    "error": None,
                },
            )

        @app.post("/profile/update-photo")
        async def update_photo(request: Request, photo_url: str = Form(...)):
            log.info(f"Updating photo to URL: {photo_url}")
            token = cookie.get_token(request)
            if not token:
                return RedirectResponse(url="/login", status_code=302)
            msg = None
            err = None
            try:
                await gateway.set_user_photo(token, photo_url)
                msg = "Photo updated"
            except Exception as e:
                log.warning("Error updating photo", exc_info=e)
                err = str(e)
            info = await profile.fetch_user_and_photo(token)
            return templates.TemplateResponse(
                "profile.html",
                {
                    "request": request,
                    "user": info.get("user"),
                    "photo_url": info.get("photo_url"),
                    "message": msg,
                    "error": err,
                },
            )

        @app.get("/get-flag", response_class=HTMLResponse)
        async def flag_page(request: Request):
            token = cookie.get_token(request)
            if not token:
                return RedirectResponse(url="/login", status_code=302)

            flag = None
            try:
                flag = await gateway.get_flag(token)
            except Exception as e:
                log.warning(f"Failed to retrieve flag: {e}")

            return templates.TemplateResponse(
                "flag.html",
                {
                    "request": request,
                    "flag": flag,
                },
            )

        @app.get("/logout")
        async def logout():
            resp = RedirectResponse(url="/login", status_code=302)
            cookie.clear(resp)
            return resp

        @app.get("/health")
        async def health_check():
            return {"status": "ok"}


def create_app() -> FastAPI:
    return HarborApp().app
