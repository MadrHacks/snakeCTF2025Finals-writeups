package wayfinder

import (
	"encoding/json"
	"fmt"
	"net/url"
)

func ServiceModelToQueryParams(sm ServiceModel) url.Values {
	params := url.Values{}
	params.Add("service_type", string(sm.ServiceType))
	params.Add("service_address", sm.IP)
	params.Add("service_port", fmt.Sprintf("%d", sm.Port))

	return params
}

func JSONToServiceModel(data []byte) (ServiceModel, error) {
	var sm ServiceModel
	err := json.Unmarshal(data, &sm)
	if err != nil {
		return ServiceModel{}, fmt.Errorf("failed to unmarshal JSON to service model: %w", err)
	}

	return sm, nil
}
