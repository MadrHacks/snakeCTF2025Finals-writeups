package wayfinder

type ServiceType string

const (
	AuthService     ServiceType = "buccaneer"
	FlagService     ServiceType = "treasure"
	FrontEndService ServiceType = "sloop"
)

type ServiceModel struct {
	ServiceType ServiceType `json:"service_type"`
	IP          string      `json:"ip"`
	Port        int         `json:"port"`
}
