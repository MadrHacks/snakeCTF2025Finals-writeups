package gateway

import (
	"buccaneer/gateway/wayfinder"

	"go.uber.org/fx"
)

var Module = fx.Module("gateway",
	fx.Provide(
		wayfinder.New,
	),
	fx.Invoke(func(*wayfinder.Gateway) {}),
)
