package register

import (
	"encoding/json"
	"net/http"

	"buccaneer/controller/account"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Handler struct {
	log               *zap.Logger
	accountController *account.Controller
}

type HandlerParams struct {
	fx.In

	Logger            *zap.Logger
	AccountController *account.Controller
}

func New(params HandlerParams) (*Handler, error) {
	return &Handler{
		log:               params.Logger,
		accountController: params.AccountController,
	}, nil
}

func (*Handler) Pattern() string {
	return "/register"
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	queryParams := r.URL.Query()
	userInput := QueryToUserInput(queryParams)

	token, err := h.accountController.Register(userInput)
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		h.log.With(zap.Any("userParams", userInput)).Warn("failed to register", zap.Error(err))
	}

	payload, err := json.Marshal(map[string]string{
		"token": token,
	})
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		h.log.Error("failed to marshal token", zap.Error(err))
		return
	}

	_, err = w.Write(payload)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		h.log.Error("failed to write payload", zap.Error(err))
		return
	}
}
