package login

import (
	"net/url"

	"buccaneer/controller/account"
)

func QueryToUserInput(queryParams url.Values) account.UserInput {
	username := queryParams.Get("username")
	password := queryParams.Get("password")

	return account.UserInput{
		Username: username,
		Password: password,
	}
}
