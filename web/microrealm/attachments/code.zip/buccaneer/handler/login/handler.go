package login

import (
	"encoding/json"
	"net/http"

	"buccaneer/controller/account"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Handler struct {
	log               *zap.Logger
	accountController *account.Controller
}

type HandlerParams struct {
	fx.In

	Logger            *zap.Logger
	AccountController *account.Controller
}

func New(params HandlerParams) (*Handler, error) {
	return &Handler{
		log:               params.Logger,
		accountController: params.AccountController,
	}, nil
}

func (*Handler) Pattern() string {
	return "/login"
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	queryParams := r.URL.Query()
	userInput := QueryToUserInput(queryParams)

	h.log.Info("Received login request", zap.String("username", userInput.Username))

	token, err := h.accountController.Login(userInput)
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		h.log.Warn("failed to login")
	}

	payload, err := json.Marshal(map[string]string{
		"token": token,
	})
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		h.log.Error("failed to marshal token", zap.Error(err))
		return
	}

	_, err = w.Write(payload)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		h.log.Error("failed to write payload", zap.Error(err))
		return
	}
}
