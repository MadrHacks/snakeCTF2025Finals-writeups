package handler

import (
	"buccaneer/handler/health"
	"buccaneer/handler/login"
	"buccaneer/handler/register"
	"buccaneer/handler/verifytoken"
	"buccaneer/server/http"

	"go.uber.org/fx"
)

func asHTTPRoute(f any) any {
	return fx.Annotate(
		f,
		fx.As(new(http.Route)),
		fx.ResultTags(`group:"http-routes"`),
	)
}

var Module = fx.Module("handler",
	fx.Provide(
		asHTTPRoute(verifytoken.New),
		asHTTPRoute(register.New),
		asHTTPRoute(login.New),
		asHTTPRoute(health.New),
	),
)
