package verifytoken

import (
	"encoding/json"
	"net/http"

	"buccaneer/controller/account"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Handler struct {
	log               *zap.Logger
	accountController *account.Controller
}

type HandlerParams struct {
	fx.In

	Logger            *zap.Logger
	AccountController *account.Controller
}

func New(params HandlerParams) (*Handler, error) {
	return &Handler{
		log:               params.Logger,
		accountController: params.AccountController,
	}, nil
}

func (*Handler) Pattern() string {
	return "/verify-token"
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	queryParams := r.URL.Query()
	token := queryParams.Get("token")

	user, err := h.accountController.VerifyToken(token)
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		h.log.Warn("failed to verify token")
	}

	payload, err := json.Marshal(user)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		h.log.Error("failed to marshal userphoto data", zap.Error(err))
		return
	}

	_, err = w.Write(payload)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		h.log.Error("failed to write payload", zap.Error(err))
		return
	}
}
