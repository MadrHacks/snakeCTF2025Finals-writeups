package account

type Token string

type User struct {
	ID           int    `json:"id"`
	Username     string `json:"username"`
	PasswordHash string `json:"password_hash"`
	IsAdmin      bool   `json:"is_admin"`
}

type UserInput struct {
	Username string `json:"username"`
	Password string `json:"password"`
}
