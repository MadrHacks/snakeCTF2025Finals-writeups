package account

import (
	"crypto/sha256"
	"fmt"
	"math/rand/v2"

	"github.com/golang-jwt/jwt/v5"
	"go.uber.org/fx"
	"go.uber.org/zap"
)

var (
	letterRunes = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
)

type Controller struct {
	log *zap.Logger

	users  map[int]User
	tokens map[int]string

	key string
}

type ControllerParams struct {
	fx.In

	Logger *zap.Logger
}

func New(params ControllerParams) (*Controller, error) {
	randomKey := randomString(16)

	return &Controller{
		log:    params.Logger,
		users:  map[int]User{},
		tokens: map[int]string{},
		key:    randomKey,
	}, nil
}

func (c *Controller) Register(userInput UserInput) (string, error) {
	passwordHash, err := hashPassword(userInput.Password)
	if err != nil {
		return "", fmt.Errorf("failed to hash password: %w", err)
	}
	userId, err := generateUserID()
	if err != nil {
		return "", fmt.Errorf("failed to generate user id: %w", err)
	}

	user := User{
		ID:           userId,
		PasswordHash: passwordHash,
		Username:     userInput.Username,
		IsAdmin:      false,
	}
	err = c.addUser(user)
	if err != nil {
		return "", fmt.Errorf("failed to add user: %w", err)
	}

	token, err := c.generateToken(user)
	if err != nil {
		return "", fmt.Errorf("failed to generate token: %w", err)
	}

	return token, nil
}

func (c *Controller) Login(userInput UserInput) (string, error) {
	passwordHash, err := hashPassword(userInput.Password)
	if err != nil {
		return "", fmt.Errorf("failed to hash password: %w", err)
	}

	for _, user := range c.users {
		// TODO: ensure username is unique
		if user.Username == userInput.Username && user.PasswordHash == passwordHash {
			token, err := c.generateToken(user)
			if err != nil {
				return "", fmt.Errorf("failed to generate token: %w", err)
			}
			return token, nil
		}
	}

	return "", fmt.Errorf("invalid username or password")
}

func (c *Controller) VerifyToken(token string) (User, error) {
	user, err := c.getUserFromToken(token)
	if err != nil {
		return User{}, fmt.Errorf("failed to get user from token: %w", err)
	}

	return user, nil
}

func (c *Controller) generateToken(u User) (string, error) {

	t := jwt.NewWithClaims(jwt.SigningMethodHS256,
		jwt.MapClaims{
			"user": u,
		})
	s, err := t.SignedString([]byte(c.key))
	if err != nil {
		return "", fmt.Errorf("failed to sign token: %w", err)
	}

	return s, nil
}

func (c *Controller) getUserFromToken(t string) (User, error) {
	token, err := jwt.Parse(t, func(token *jwt.Token) (interface{}, error) {
		return []byte(c.key), nil
	})
	if err != nil {
		return User{}, fmt.Errorf("failed to parse token: %w", err)
	}

	if !token.Valid {
		return User{}, fmt.Errorf("invalid token")
	}

	claims, ok := token.Claims.(jwt.MapClaims)
	if !ok {
		return User{}, fmt.Errorf("invalid token claims")
	}

	userClaim := claims["user"].(map[string]interface{})
	user := User{
		ID:           int(userClaim["id"].(float64)),
		Username:     userClaim["username"].(string),
		PasswordHash: userClaim["password_hash"].(string),
		IsAdmin:      userClaim["is_admin"].(bool),
	}

	return user, nil
}

func (c *Controller) addUser(user User) error {
	c.users[user.ID] = user

	return nil
}

func hashPassword(password string) (string, error) {
	h := sha256.New()
	_, err := h.Write([]byte(password))
	if err != nil {
		return "", err
	}

	bs := h.Sum(nil)

	return fmt.Sprintf("%x", bs), nil
}

func generateUserID() (int, error) {
	return rand.IntN(10000000), nil
}

func randomString(n int) string {
	b := make([]rune, n)
	for i := range b {
		b[i] = letterRunes[rand.IntN(len(letterRunes))]
	}
	return string(b)
}
