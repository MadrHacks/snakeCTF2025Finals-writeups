package controller

import (
	"buccaneer/controller/account"

	"go.uber.org/fx"
)

var Module = fx.Module("controller",
	fx.Provide(
		account.New,
	),
)
