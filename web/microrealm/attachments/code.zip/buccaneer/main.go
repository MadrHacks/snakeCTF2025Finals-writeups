package main

import (
	clientHTTP "buccaneer/client/http"
	"buccaneer/controller"
	"buccaneer/gateway"
	"buccaneer/handler"
	serverHTTP "buccaneer/server/http"
	"os"

	"go.uber.org/fx"
	"go.uber.org/fx/fxevent"
	"go.uber.org/zap"
)

func main() {
	fx.New(
		// Ingress modules
		serverHTTP.Module,
		// Egress modules
		clientHTTP.Module,
		// Utility modules
		fx.Provide(
			getLogger,
		),
		fx.WithLogger(func(log *zap.Logger) fxevent.Logger {
			return &fxevent.ZapLogger{Logger: log}
		}),

		handler.Module,
		controller.Module,
		gateway.Module,
	).Run()
}

func getLogger() (*zap.Logger, error) {
	if os.Getenv("GO_ENV") == "production" {
		return zap.NewProduction()
	} else {
		return zap.NewDevelopment()
	}
}
