package register

import (
	"net/http"

	"wayfinder/controller/service"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Handler struct {
	log               *zap.Logger
	serviceController *service.Controller
}

type HandlerParams struct {
	fx.In

	Logger            *zap.Logger
	ServiceController *service.Controller
}

func New(params HandlerParams) (*Handler, error) {
	return &Handler{
		log:               params.Logger,
		serviceController: params.ServiceController,
	}, nil
}

func (*Handler) Pattern() string {
	return "/register"
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	h.log.Debug("Received request", zap.String("url", r.URL.String()))

	w.WriteHeader(http.StatusOK)

	registerRequest, err := requestToServiceModel(r)
	if err != nil {
		h.log.Error("failed to parse service request", zap.Error(err))
		http.Error(w, "invalid request", http.StatusBadRequest)
		return
	}

	h.log.Info("received service register request", zap.Any("request", registerRequest))

	err = h.serviceController.RegisterService(registerRequest)
	if err != nil {
		h.log.Error("failed to register service", zap.Error(err))
		http.Error(w, "failed to register service", http.StatusInternalServerError)
		return
	}

	w.Write([]byte("service registered"))
}
