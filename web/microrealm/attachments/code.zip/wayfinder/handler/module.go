package handler

import (
	"wayfinder/handler/getservice"
	"wayfinder/handler/health"
	"wayfinder/handler/register"
	"wayfinder/handler/unregister"
	"wayfinder/server/http"

	"go.uber.org/fx"
)

func asHTTPRoute(f any) any {
	return fx.Annotate(
		f,
		fx.As(new(http.Route)),
		fx.ResultTags(`group:"http-routes"`),
	)
}

var Module = fx.Module("handler",
	fx.Provide(
		asHTTPRoute(register.New),
		asHTTPRoute(unregister.New),
		asHTTPRoute(getservice.New),
		asHTTPRoute(health.New),
	),
)
