package unregister

import (
	"errors"
	"fmt"
	"net/http"
	"strconv"

	"wayfinder/controller/service"
)

func requestToServiceModel(req *http.Request) (service.Model, error) {
	queryParams := req.URL.Query()

	if queryParams.Has("service_address") == false {
		return service.Model{}, errors.New("service_address parameter is required")
	}
	ipAddress := queryParams.Get("service_address")

	if queryParams.Has("service_type") == false {
		return service.Model{}, errors.New("service_type parameter is required")
	}
	serviceType := queryParams.Get("service_type")

	portNumber := "8080" // default port
	if queryParams.Has("service_port") == true {
		portNumber = queryParams.Get("service_port")
	}
	portNumberInt, err := strconv.Atoi(portNumber)
	if err != nil {
		return service.Model{}, fmt.Errorf("invalid port number: %w", err)
	}

	return service.Model{
		ServiceType: service.Type(serviceType),
		IP:          ipAddress,
		Port:        portNumberInt,
	}, nil
}
