package getservice

import (
	"encoding/json"
	"errors"
	"net/http"

	"wayfinder/controller/service"
)

func serviceModelToResponse(s service.Model) ([]byte, error) {
	response, err := json.Marshal(s)

	if err != nil {
		return []byte(""), errors.New("failed to marshal serviceModel to JSON")
	}

	return response, nil
}

func requestToServiceType(req *http.Request) (service.Type, error) {
	queryParams := req.URL.Query()

	if queryParams.Has("service_type") == false {
		return "", errors.New("service_type parameter is required")
	}
	serviceType := queryParams.Get("service_type")

	return service.Type(serviceType), nil
}
