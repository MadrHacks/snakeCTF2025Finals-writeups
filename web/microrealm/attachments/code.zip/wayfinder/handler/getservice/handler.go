package getservice

import (
	"net/http"

	"wayfinder/controller/service"

	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Handler struct {
	log               *zap.Logger
	serviceController *service.Controller
}

type HandlerParams struct {
	fx.In

	Logger            *zap.Logger
	ServiceController *service.Controller
}

func New(params HandlerParams) (*Handler, error) {
	return &Handler{
		log:               params.Logger,
		serviceController: params.ServiceController,
	}, nil
}

func (*Handler) Pattern() string {
	return "/get-service"
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	h.log.Debug("Received request", zap.String("url", r.URL.String()))

	w.WriteHeader(http.StatusOK)

	serviceType, err := requestToServiceType(r)
	if err != nil {
		h.log.Error("failed to parse service model", zap.Error(err))
		http.Error(w, "invalid request", http.StatusBadRequest)
		return
	}

	serviceModel, err := h.serviceController.GetService(serviceType)
	if err != nil {
		h.log.Error("failed to get servicel", zap.Error(err))
		http.Error(w, "failed to get service", http.StatusInternalServerError)
		return
	}
	if serviceModel == nil {
		h.log.Info("no service found", zap.String("service_type", string(serviceType)))
		http.Error(w, "service not found", http.StatusNotFound)
		return
	}

	h.log.With(
		zap.String("service_type", string(serviceType)),
		zap.Any("servicel", serviceModel),
	).Info("received get service request")

	response, err := serviceModelToResponse(*serviceModel)
	if err != nil {
		h.log.Error("failed to map service model to response", zap.Error(err))
		http.Error(w, "failed to process service data", http.StatusInternalServerError)
		return
	}

	_, err = w.Write(response)
	if err != nil {
		h.log.Error("failed to write payload", zap.Error(err))
		http.Error(w, "failed to write payload", http.StatusInternalServerError)
		return
	}
}
