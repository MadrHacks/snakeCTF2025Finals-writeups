package service

import (
	"errors"
	
	"go.uber.org/fx"
	"go.uber.org/zap"
)

type Controller struct {
	log *zap.Logger

	services map[Type][]Model
}

type ControllerParams struct {
	fx.In

	Logger *zap.Logger
}

func New(params ControllerParams) (*Controller, error) {
	return &Controller{
		log:      params.Logger,
		services: map[Type][]Model{},
	}, nil
}

func (c *Controller) RegisterService(req Model) error {
	serviceType := req.ServiceType

	c.services[serviceType] = append(c.services[serviceType], req)
	c.log.Info("service registered", zap.Any("service", req))
	// print the whole services map
	c.log.Debug("current services", zap.Any("services", c.services))


	return nil
}

func (c *Controller) UnregisterService(req Model) error {
	serviceType := req.ServiceType

	if c.services[serviceType] == nil {
		return errors.New("service type not registered")
	}

	// Find and remove the service with matching IP and Port
	services := c.services[serviceType]
	for i, service := range services {
		if service.IP == req.IP && service.Port == req.Port {
			// Remove the service from the slice
			c.services[serviceType] = append(services[:i], services[i+1:]...)
			c.log.Info("service unregistered", zap.Any("service", req))
			return nil
		}
	}

	return errors.New("service not found")
}

func (c *Controller) GetService(serviceType Type) (*Model, error) {
	if c.services[serviceType] == nil || len(c.services[serviceType]) == 0 {
		return nil, nil
	}

	// Return the first available service (could implement load balancing here)
	service := c.services[serviceType][0]
	return &service, nil
}
