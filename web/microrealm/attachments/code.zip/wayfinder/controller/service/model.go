package service

type Type string

const (
	AuthService     Type = "buccaneer"
	FlagService     Type = "treasure"
	FrontEndService Type = "sloop"
)

type Model struct {
	ServiceType Type   `json:"service_type"`
	IP          string `json:"ip"`
	Port        int    `json:"port"`
}
