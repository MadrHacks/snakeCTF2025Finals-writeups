package controller

import (
	"wayfinder/controller/service"

	"go.uber.org/fx"
)

var Module = fx.Module("controller",
	fx.Provide(
		service.New,
	),
)
